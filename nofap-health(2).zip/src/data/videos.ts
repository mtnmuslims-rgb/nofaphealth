import { VideoTalk } from '../types';

export const VIDEO_TALKS: VideoTalk[] = [
  {
    id: 'first-72-hours',
    title: 'Breaking the 3-Day Cycle: Navigating the Critical First 72 Hours',
    duration: '14:20',
    category: 'Relapse Prevention',
    description: 'Why days 2 through 4 represent the highest friction point in habit change, how acute withdrawal symptoms manifest, and the exact protocols to cross the 3-day bridge.',
    keyMoments: [
      { time: '01:15', topic: 'Why the 72-hour mark triggers intense craving spikes' },
      { time: '04:30', topic: 'The illusion of bargaining ("Just 2 minutes")' },
      { time: '08:45', topic: 'The Cold-Air & Cold-Water physiological interrupt' },
      { time: '12:10', topic: 'Locking down your nightstand setup' }
    ],
    summary: 'The initial 72 hours demand acute physiological friction and immediate pattern disruption. Once you clear this initial hump, cognitive clarity begins to stabilize.',
    reflectionPrompt: 'What specific trigger or rationalization usually derails you around Day 3, and what physical action will you take instead?'
  },
  {
    id: 'stop-peeking-compromise',
    title: 'The Lie of "Peeking": Why You Cannot Negotiate with Compulsive Loops',
    duration: '18:05',
    category: 'Habit Architecture',
    description: 'A deep exploration of the micro-steps leading to relapse. How opening an "innocent" social media explore tab starts the neurochemical cascade hours before a physical slip.',
    keyMoments: [
      { time: '02:00', topic: 'The pre-relapse mindset: rationalizing the peek' },
      { time: '06:40', topic: 'How the brain registers suggestive images as open tabs' },
      { time: '11:15', topic: 'Closing the door at Stage 0 rather than Stage 4' },
      { time: '15:30', topic: 'The 3-second rule for unexpected internet triggers' }
    ],
    summary: 'Relapses never happen in an instant; they are the final domino in a chain that began 4 hours earlier with casual, unfocused browsing. Eliminating the first compromise protects the entire day.',
    reflectionPrompt: 'Which app or website is your most frequent Trojan horse for peeking, and what friction can you implement on that platform today?'
  },
  {
    id: 'handling-relapse-shame',
    title: 'Recovering from a Slip Without Destroying All Your Hard-Earned Progress',
    duration: '16:45',
    category: 'Mindset & Resilience',
    description: 'Differentiating between a momentary lapse and a total collapse. How toxic shame and the "Chaser Effect" keep you trapped in multi-day benders, and how to stop it cold.',
    keyMoments: [
      { time: '01:40', topic: 'The difference between a lapse and a relapse' },
      { time: '05:10', topic: 'Why shame is the gasoline that feeds compulsive behavior' },
      { time: '09:25', topic: 'The 24-hour Chaser Effect and heightened vulnerability' },
      { time: '13:50', topic: 'Documenting the trigger: post-mortem analysis' }
    ],
    summary: 'A slip resets your counter, but it does not erase the neuroplastic healing and discipline you built during your streak. Treat a slip as clinical diagnostic data, not a moral indictment.',
    reflectionPrompt: 'If a friend called you in distress after a slip, what compassionate yet firm advice would you give him? Now offer that same honesty to yourself.'
  },
  {
    id: 'building-real-discipline',
    title: 'Replacing the Void: Building Physical Self-Discipline in the Real World',
    duration: '21:10',
    category: 'Lifestyle Rebuild',
    description: 'Quitting a bad habit is only half the formula. If you do not build meaningful, challenging, and dopamine-rich constructive habits in real life, the old habit will return.',
    keyMoments: [
      { time: '02:15', topic: 'The vacuum effect: why empty hours breed temptation' },
      { time: '07:30', topic: 'Heavy resistance training and cardiovascular exertion' },
      { time: '12:45', topic: 'Developing creative craft and technical skills' },
      { time: '17:20', topic: 'Real-world social connection vs digital isolation' }
    ],
    summary: 'You cannot simply eliminate a habit; you must transmute that intense biological drive and focus into heavy lifting, deep work, meaningful relationships, and tangible craftsmanship.',
    reflectionPrompt: 'What physical hobby, sport, or skill have you neglected that you can immediately fill your evening schedule with?'
  }
];
