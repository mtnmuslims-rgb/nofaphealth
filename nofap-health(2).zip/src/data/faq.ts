import { FaqItem } from '../types';

export const FAQ_DATA: FaqItem[] = [
  {
    category: 'Disclaimer & Approach',
    question: 'Are you a licensed medical doctor or clinical therapist?',
    answer: 'No. The founder and guides at NoFap Health are not medical doctors, licensed psychiatrists, or clinical psychologists. We provide non-clinical personal guidance, lifestyle habit coaching, and peer accountability based on approximately 7–8 years of direct personal experience helping hundreds of men break free from compulsive loops. We never make medical claims, prescribe medications, or guarantee clinical recovery. If you are struggling with severe psychological disorders or trauma, we strongly advise consulting a licensed mental healthcare professional.'
  },
  {
    category: 'Privacy & Confidentiality',
    question: 'Can I remain completely anonymous during guidance sessions?',
    answer: 'Yes, absolutely. We respect your complete privacy. You are welcome to use a pseudonym or first name only. You do not need to turn on your camera if you prefer audio-only calls via Telegram, Signal, Google Meet, or Zoom. Everything discussed between us remains strictly confidential.'
  },
  {
    category: 'Guidance & Sessions',
    question: 'What actually happens during a 1-on-1 personal guidance session?',
    answer: 'Sessions are practical, empathetic, and forward-looking. We do not spend hours wallowing in guilt or shame. Instead, we perform a structured audit of your typical day, pinpoint the exact environmental cues and emotional triggers that lead to slips, diagnose previous failed attempts, and build a concrete, step-by-step strategy for the upcoming week with tailored friction and habit substitutes.'
  },
  {
    category: 'Guidance & Sessions',
    question: 'How does weekly accountability support work throughout the month?',
    answer: 'Between our scheduled 1-on-1 calls, you have direct messaging contact for check-ins. You send a quick evening or morning status, report any high-risk moments, and receive prompt, grounded feedback. If you feel an acute urge wave swelling, you can send an emergency message to interrupt the loop before acting on it.'
  },
  {
    category: 'Habits & Relapse',
    question: 'What happens if I experience a relapse while enrolled in guidance?',
    answer: 'We do not shame, judge, or lecture you. A slip is not the end of the world; it is diagnostic data. We immediately conduct an honest debrief: What time was it? Where was your phone? What emotional state preceded it? We extract the lesson, patch the structural vulnerability in your environment, and get you immediately back on track before the chaser effect takes hold.'
  },
  {
    category: 'Guidance & Sessions',
    question: 'Is this guidance suitable for both religious and secular backgrounds?',
    answer: 'Yes. Our guidance focuses on universal neurobiology, environmental architecture, behavioral psychology, and practical habit restructuring. Whether you are motivated by spiritual convictions, personal self-respect, marital commitment, or cognitive clarity, our methods respect your personal values without imposing any dogmatic doctrine.'
  },
  {
    category: 'Guidance & Sessions',
    question: 'What timezones do you accommodate for international clients?',
    answer: 'We work with clients across North America, Europe, the Middle East, Asia, and Australasia. We offer flexible scheduling blocks across multiple timezone windows to accommodate working professionals, students, and fathers worldwide.'
  }
];
