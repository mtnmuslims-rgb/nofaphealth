export type Language = 'en' | 'ur';

export interface Translations {
  nav: {
    home: string;
    about: string;
    education: string;
    guidance: string;
    contact: string;
    whatsappButton: string;
  };
  hero: {
    brandName: string;
    brandTagline: string;
    heading: string;
    description: string;
    whatsappButton: string;
    reassuranceBadge: string;
    oneClickNotice: string;
  };
  about: {
    badge: string;
    heading: string;
    statYearsNumber: string;
    statYearsLabel: string;
    statGuidedNumber: string;
    statGuidedLabel: string;
    p1: string;
    p2: string;
    p3: string;
    callout: string;
    experienceBadge: string;
    nonClinicalBadge: string;
    disclaimer: string;
  };
  education: {
    badge: string;
    title: string;
    intro: string;
    experiencesVaryNote: string;
    effectsTitle: string;
    effects: string[];
    // Section 3: Why watching videos is not enough
    whyVideosBadge: string;
    whyVideosTitle: string;
    whyVideosP1: string;
    whyVideosP2: string;
    partnerTitle: string;
    partnerBenefits: string[];
    // Section 4: A Personal Message
    personalMsgBadge: string;
    personalMsgTitle: string;
    personalMsgP1: string;
    personalMsgP2: string;
    personalMsgHighlight: string;
    personalMsgCta: string;
    // Section 5: Your Privacy Matters
    privacyBadge: string;
    privacyTitle: string;
    privacyP1: string;
    privacyP2: string;
    privacyHighlight: string;
    privacyPracticeNote: string;
  };
  accountability: {
    badge: string;
    heading: string;
    p1: string;
    p2: string;
    p3: string;
    highlight: string;
  };
  guidancePlans: {
    heading: string;
    description: string;
    badge: string;
    discussionNote: string;
    plans: {
      weekly: {
        title: string;
        duration: string;
        description: string;
        buttonText: string;
        whatsappMessage: string;
      };
      fifteen: {
        title: string;
        duration: string;
        description: string;
        buttonText: string;
        whatsappMessage: string;
      };
      monthly: {
        title: string;
        duration: string;
        description: string;
        buttonText: string;
        whatsappMessage: string;
      };
    };
  };
  milestones: {
    badge: string;
    title: string;
    subheading: string;
    stages: Array<{
      stageNumber: string;
      days: string;
      title: string;
      focus: string;
      experience: string;
      guidanceSupport: string;
    }>;
    note: string;
    roadmapCta: string;
  };
  testimonials: {
    badge: string;
    title: string;
    subheading: string;
    privacyNotice: string;
    stories: Array<{
      tag: string;
      milestone: string;
      quote: string;
      keyTakeaway: string;
      impactArea: string;
    }>;
    ctaText: string;
    ctaButton: string;
  };
  contact: {
    badge: string;
    heading: string;
    subheading: string;
    nameLabel: string;
    nameValue: string;
    emailLabel: string;
    emailValue: string;
    whatsappButton: string;
    emailButton: string;
    phoneNumber: string;
    availability: string;
    coreMessage: string;
    privacyAssurance: string;
  };
  footer: {
    tagline: string;
    founderLabel: string;
    founderName: string;
    emailLabel: string;
    emailValue: string;
    contactLabel: string;
    disclaimer: string;
    copyright: string;
    rights: string;
  };
  floatingButtonTooltip: string;
  prefilledWhatsAppMessage: string;
}

export const FOUNDER_NAME = 'Waseem Abbas';
export const FOUNDER_EMAIL = 'nofapht@gmail.com';
export const OFFICIAL_PHONE = '+92 309 8106340';
export const OFFICIAL_WHATSAPP_BASE = 'https://wa.me/923098106340';

export const TRANSLATIONS: Record<Language, Translations> = {
  en: {
    nav: {
      home: 'Home',
      about: 'About Me',
      education: 'Education',
      guidance: 'Personal Guidance',
      contact: 'Contact',
      whatsappButton: 'Chat on WhatsApp',
    },
    hero: {
      brandName: 'NOFAP HEALTH',
      brandTagline: 'Live Healthy • Think Positive • Be Better',
      heading: 'You Are Not Alone. Take Control of Your Life.',
      description: 'Struggling with unhealthy habits or compulsive pornography use? NoFap Health provides personal guidance, accountability support, and practical strategies to help you build a healthier lifestyle.',
      whatsappButton: 'CHAT WITH ME ON WHATSAPP',
      reassuranceBadge: '100% Confidential · Direct 1-on-1 Guidance · Real Accountability',
      oneClickNotice: 'YOU ARE NOT ALONE. PERSONAL GUIDANCE IS JUST ONE CLICK AWAY.',
    },
    about: {
      badge: '9 YEARS OF EXPERIENCE · REAL MENTORSHIP',
      heading: '9 Years of Experience. Thousands of People Guided.',
      statYearsNumber: '9+',
      statYearsLabel: 'Years of Experience',
      statGuidedNumber: 'Thousands',
      statGuidedLabel: 'People Guided',
      p1: 'For the past 9 years, I have guided thousands of people on their NoFap journeys. Through these experiences, I have gained valuable insights into the challenges people face, their struggles, and the habits that can help them move forward.',
      p2: 'I have supported many individuals in completing their NoFap challenges and making positive changes in their lives.',
      p3: 'Now, with 9 years of experience, practical understanding, and personal guidance, I want to help you too. I can support you in staying consistent, managing setbacks, building healthier habits, and working towards your personal goals.',
      callout: 'You Are Not Alone. I Am Here to Guide You.',
      experienceBadge: '9 Years of Experience',
      nonClinicalBadge: 'Non-Clinical Personal Guidance',
      disclaimer: 'I am not a medical doctor, licensed therapist, or clinical psychologist. I provide non-clinical personal guidance, lifestyle habit coaching, and peer accountability based on 9 years of personal experience.',
    },
    education: {
      badge: 'EDUCATIONAL INSIGHTS',
      title: 'Understanding the Effects of Pornography and Excessive Masturbation',
      intro: "Pornography and excessive or compulsive sexual habits can affect some people's daily lives, routines, and personal well-being.",
      experiencesVaryNote: 'Experiences vary from person to person. Problems are more likely when habits become compulsive or interfere with everyday responsibilities, work, or relationships.',
      effectsTitle: 'Some individuals may experience:',
      effects: [
        'Difficulty controlling repeated habits or urges.',
        'Loss of time and reduced productivity.',
        'Difficulty concentrating on daily responsibilities.',
        'Feelings of guilt, stress, or frustration.',
        'Unrealistic expectations about intimacy and relationships.',
        'Problems maintaining a healthy balance in everyday life.',
      ],
      // Section 3
      whyVideosBadge: 'BEYOND INFORMATION',
      whyVideosTitle: 'Why Watching Videos and Reading Articles May Not Be Enough',
      whyVideosP1: 'Reading articles and watching educational videos can provide useful knowledge and motivation. However, for some people, information alone may not be enough to break repeated habits or maintain long-term consistency.',
      whyVideosP2: 'Real progress may require more than just watching videos or reading motivational content. Having an accountability partner, personal guidance, regular support, and someone who understands your challenges can make the journey easier.',
      partnerTitle: 'An accountability partner can help you:',
      partnerBenefits: [
        'Stay focused on your personal goals.',
        'Recognize triggers and understand your habits.',
        'Maintain consistency and discipline.',
        'Track your progress and discuss setbacks without judgment.',
        'Build healthier routines and positive habits.',
      ],
      // Section 4
      personalMsgBadge: 'DIRECT PERSONAL SUPPORT',
      personalMsgTitle: "You Don't Have to Do It Alone.",
      personalMsgP1: 'Sometimes, all you need is someone who understands your struggles, listens without judging you, and helps you stay accountable.',
      personalMsgP2: 'With 9 years of experience guiding thousands of people, I want to use my practical experience to help you work towards your personal NoFap goals.',
      personalMsgHighlight: 'You Are Not Alone. Take the First Step Towards Positive Change.',
      personalMsgCta: 'GET PERSONAL GUIDANCE',
      // Section 5
      privacyBadge: 'SAFE & RESPECTFUL COMMUNICATION',
      privacyTitle: 'Your Privacy Is Our Priority.',
      privacyP1: 'We understand that discussing personal habits and challenges can feel difficult. Please feel comfortable reaching out. Your privacy and personal information will be treated with care, respect, and confidentiality.',
      privacyP2: 'You can share your concerns without feeling embarrassed or judged. Your personal journey deserves understanding, respect, and privacy.',
      privacyHighlight: 'Feel Safe. Speak Freely. Your Privacy Matters.',
      privacyPracticeNote: 'All inquiries and 1-on-1 conversations are handled directly and privately via secure WhatsApp and direct email without third-party sharing.',
    },
    accountability: {
      badge: 'BEYOND INFORMATION',
      heading: 'Sometimes, You Need More Than Just Information.',
      p1: 'You may have watched countless videos, read articles, and tried many times to change your habits. But sometimes, you still find yourself going back to old patterns.',
      p2: 'This is where personal guidance and accountability can help.',
      p3: 'Having someone to guide you step by step, discuss your challenges, and help you stay focused can make your journey more structured.',
      highlight: "Don't Just Watch Videos. Take Action With Personal Guidance.",
    },
    guidancePlans: {
      badge: 'FLEXIBLE ONE-TO-ONE SUPPORT',
      heading: 'One-to-One Personal Guidance',
      description: "Everyone's journey is different. Choose the guidance duration that works best for you.",
      discussionNote: 'Contact me directly on WhatsApp to discuss plan details and get started. 100% confidential.',
      plans: {
        weekly: {
          title: 'WEEKLY GUIDANCE',
          duration: '7 Days Support',
          description: 'Personal one-to-one guidance and accountability support on a weekly basis.',
          buttonText: 'Choose Weekly Plan',
          whatsappMessage: 'Hello, I am interested in your Weekly One-to-One Personal Guidance Plan. Please share the details.',
        },
        fifteen: {
          title: '15-DAY GUIDANCE',
          duration: '15 Days Support',
          description: 'Personal guidance and accountability support for 15 days.',
          buttonText: 'Choose 15-Day Plan',
          whatsappMessage: 'Hello, I am interested in your 15-Day One-to-One Personal Guidance Plan. Please share the details.',
        },
        monthly: {
          title: 'MONTHLY GUIDANCE',
          duration: '1 Month Full Support',
          description: 'Extended one-to-one personal guidance and accountability support for one month.',
          buttonText: 'Choose Monthly Plan',
          whatsappMessage: 'Hello, I am interested in your Monthly One-to-One Personal Guidance Plan. Please share the details.',
        },
      },
    },
    milestones: {
      badge: 'VISUAL RECOVERY ROADMAP',
      title: 'Progress Milestones: Typical Stages of Habit Change',
      subheading: 'A reassuring visual guide showing the common phases of rewiring habits, managing urges, and building lasting self-discipline.',
      note: 'Realistic Reminder: Progress is personal and rarely a straight line. Setbacks are learning opportunities, not total resets. Guidance provides steady direction across every phase.',
      roadmapCta: 'Have questions about where you are on this journey? Message me for personal guidance.',
      stages: [
        {
          stageNumber: '01',
          days: 'Days 1 – 7',
          title: 'Breaking the Autopilot Loop',
          focus: 'Recognizing immediate triggers, establishing phone and evening boundaries, and breaking unconscious habit patterns.',
          experience: 'Restlessness, frequent craving waves, and the brain reaching out for comfortable habits during downtime.',
          guidanceSupport: 'Daily check-ins to handle early friction and build fast emotional grounding.',
        },
        {
          stageNumber: '02',
          days: 'Days 8 – 21',
          title: 'Habit Restructuring & Urge Management',
          focus: 'Replacing passive screen time with physical exercise, structured sleep, and proactive urge diversion.',
          experience: 'Dopamine dips, occasional mood swings, and boredom as the mind recalibrates to normal stimulation.',
          guidanceSupport: 'Non-judgmental accountability to prevent rationalizing slips when willpower feels low.',
        },
        {
          stageNumber: '03',
          days: 'Days 22 – 45',
          title: 'Navigating the Plateau & Consistency',
          focus: 'Maintaining discipline after the initial burst of novelty fades; staying steady through emotional flatlines.',
          experience: 'Temporary emotional numbness or fatigue (the flatline phase), with questions about whether progress is working.',
          guidanceSupport: 'Calm reassurance and perspective from someone who has guided thousands through this exact phase.',
        },
        {
          stageNumber: '04',
          days: 'Days 46 – 90+',
          title: 'Sustainable Self-Discipline & Identity Shift',
          focus: 'Consolidating healthier routines, rebuilding self-respect, and establishing relapse-prevention protocols.',
          experience: 'Clearer mental focus, restored presence in relationships, higher natural energy, and genuine self-trust.',
          guidanceSupport: 'Long-term maintenance strategies and guidance for ongoing personal growth.',
        },
      ],
    },
    testimonials: {
      badge: 'REAL IMPACT · ANONYMIZED EXPERIENCES',
      title: 'Stories of Habit Change and Personal Guidance',
      subheading: 'Real examples of how structured one-to-one accountability helped individuals break repetitive cycles and rebuild daily discipline.',
      privacyNotice: 'Client Privacy: All personal names, locations, and identifiable details have been generalized or omitted to guarantee 100% confidentiality. Experiences represent real personal guidance outcomes.',
      stories: [
        {
          tag: 'Working Professional · Anonymous',
          milestone: 'Broke 2-Week Relapse Cycle · 5 Months Consistent',
          quote: 'For four years, I got stuck in the same loop—restarting every 10 to 14 days and feeling completely defeated. What changed was having a real person to check in with every single day. Discussing my triggers openly removed the shame and gave me practical accountability.',
          keyTakeaway: 'Daily check-ins replaced willpower with dependable structure.',
          impactArea: 'Career Focus & Discipline',
        },
        {
          tag: 'University Student · Anonymous',
          milestone: 'Overcame Late-Night Urges · 90-Day Challenge Completed',
          quote: 'My worst struggle was late-night studying alone in my room. Having non-judgmental guidance helped me redesign my sleep schedule, move devices outside my bedroom, and build regular gym habits. My concentration and academic results improved dramatically.',
          keyTakeaway: 'Focusing on healthy routine replacement rather than pure suppression.',
          impactArea: 'Mental Clarity & Sleep',
        },
        {
          tag: 'International Client · Anonymous',
          milestone: 'Ended the All-or-Nothing Binge Mentality',
          quote: 'Previously, whenever I slipped, self-hatred led me into weeks of compulsive binges. With Waseem’s guidance, I learned how to analyze setbacks calmly, identify what went wrong, and regain momentum immediately without despair.',
          keyTakeaway: 'Learning to handle slips calmly prevented endless binge cycles.',
          impactArea: 'Emotional Resilience',
        },
        {
          tag: 'Family Man · Anonymous',
          milestone: 'Rebuilt Self-Respect & Cleared Brain Fog · 6 Months',
          quote: 'Living with secret habits was mentally exhausting and created constant brain fog. Direct guidance gave me realistic daily tools to manage workplace stress without escaping into pornography. I feel truly present with my family now.',
          keyTakeaway: 'Eliminating secrecy restored genuine emotional presence.',
          impactArea: 'Family Presence & Self-Respect',
        },
      ],
      ctaText: 'Your journey deserves guidance, patience, and zero judgment.',
      ctaButton: 'TALK TO WASEEM ON WHATSAPP',
    },
    contact: {
      badge: 'DIRECT CONTACT & GUIDANCE',
      heading: 'Ready to Break Free? Contact Me Directly.',
      subheading: 'Reach out to discuss guidance, ask questions, or begin your accountability plan with total discretion.',
      nameLabel: 'Guide & Founder',
      nameValue: FOUNDER_NAME,
      emailLabel: 'Official Email',
      emailValue: FOUNDER_EMAIL,
      whatsappButton: 'CONTACT ME ON WHATSAPP',
      emailButton: 'SEND AN EMAIL',
      phoneNumber: OFFICIAL_PHONE,
      availability: 'Available for international clients worldwide · Discretion guaranteed',
      coreMessage: 'YOU ARE NOT ALONE. PERSONAL GUIDANCE IS JUST ONE CLICK AWAY.',
      privacyAssurance: 'Your privacy is our priority. Feel safe to speak freely without judgment.',
    },
    footer: {
      tagline: 'Helping People Build Healthier Habits and Better Lives.',
      founderLabel: 'Personal Guide:',
      founderName: FOUNDER_NAME,
      emailLabel: 'Direct Email:',
      emailValue: FOUNDER_EMAIL,
      contactLabel: 'Official WhatsApp:',
      disclaimer: 'NoFap Health provides educational information and non-clinical personal guidance. It is not a medical or mental health clinic and does not replace professional healthcare advice.',
      copyright: 'NoFap Health. Dedicated to personal freedom and discipline.',
      rights: 'All rights reserved.',
    },
    floatingButtonTooltip: 'Chat on WhatsApp',
    prefilledWhatsAppMessage: 'Hello Waseem, I visited NoFap Health and I am interested in your personal guidance plan. Please share more details.',
  },
  ur: {
    nav: {
      home: 'ہوم',
      about: 'میرے بارے میں',
      education: 'تعلیم و آگاہی',
      guidance: 'ذاتی رہنمائی',
      contact: 'رابطہ',
      whatsappButton: 'واٹس ایپ پر رابطہ کریں',
    },
    hero: {
      brandName: 'نو فپ ہیلتھ',
      brandTagline: 'صحت مند رہیں • مثبت سوچیں • بہتر بنیں',
      heading: 'آپ اکیلے نہیں ہیں۔ اپنی زندگی کا کنٹرول سنبھالیں۔',
      description: 'کیا آپ غیر صحت بخش عادات یا فحش مواد کے استعمال کی وجہ سے پریشان ہیں؟ نو فپ ہیلتھ (NoFap Health) آپ کو ایک صحت مند اور پُرسکون طرزِ زندگی اپنانے کے لیے ذاتی رہنمائی، احتسابی معاونت اور عملی تدابیر فراہم کرتا ہے۔',
      whatsappButton: 'مجھ سے واٹس ایپ پر بات کریں',
      reassuranceBadge: '100% رازدارانہ · براہِ راست ون ٹو ون رہنمائی · حقیقی احتساب',
      oneClickNotice: 'آپ اکیلے نہیں ہیں۔ ذاتی رہنمائی صرف ایک کلک کے فاصلے پر ہے۔',
    },
    about: {
      badge: '9 سالہ تجربہ · حقیقی رہنمائی',
      heading: '9 سال کا تجربہ۔ ہزاروں افراد کی رہنمائی۔',
      statYearsNumber: '9+',
      statYearsLabel: 'سال کا رہنمائی تجربہ',
      statGuidedNumber: 'ہزاروں',
      statGuidedLabel: 'افراد کی کامیاب رہنمائی',
      p1: 'گزشتہ 9 سالوں میں، میں نے ہزاروں افراد کی ان کے نو فپ (NoFap) کے سفر میں رہنمائی کی ہے۔ ان تجربات کی بدولت، مجھے ان چیلنجز، مشکلات اور ان عادات کے بارے میں گہری اور قیمتی بصیرت حاصل ہوئی ہے جو لوگوں کو آگے بڑھنے میں مدد دیتی ہیں۔',
      p2: 'میں نے بے شمار افراد کو ان کے نو فپ چیلنجز مکمل کرنے اور اپنی زندگیوں میں مثبت تبدیلیاں لانے میں مدد فراہم کی ہے۔',
      p3: 'اب، 9 سالہ تجربے، عملی فہم اور ذاتی رہنمائی کے ساتھ، میں آپ کی بھی مدد کرنا چاہتا ہوں۔ میں استقامت برقرار رکھنے، ناکامیوں سے سنبھلنے، صحت مند عادات اپنانے اور اپنے ذاتی اہداف کے حصول میں آپ کا ساتھ دے سکتا ہوں۔',
      callout: 'آپ اکیلے نہیں ہیں۔ میں آپ کی رہنمائی کے لیے موجود ہوں۔',
      experienceBadge: '9 سالہ رہنمائی کا تجربہ',
      nonClinicalBadge: 'غیر طبی ذاتی رہنمائی',
      disclaimer: 'میں کوئی میڈیکل ڈاکٹر، لائسنس یافتہ تھراپسٹ یا کلینیکل سائیکولوجسٹ نہیں ہوں۔ میں 9 سال کے ذاتی تجربے کی بنیاد پر غیر طبی ذاتی رہنمائی، طرزِ زندگی کی عادات کی کوچنگ اور ہم عصر احتساب فراہم کرتا ہوں۔',
    },
    education: {
      badge: 'تعلیمی بصیرت و آگاہی',
      title: 'پورنوگرافی اور حد سے زیادہ عادت کے اثرات کو سمجھنا',
      intro: 'پورنوگرافی اور حد سے زیادہ یا غیر اختیاری جنسی عادات بعض افراد کی روزمرہ زندگی، معمولات اور ذاتی فلاح کو متاثر کر سکتی ہیں۔',
      experiencesVaryNote: 'ہر فرد کا تجربہ مختلف ہوتا ہے۔ مسائل اس وقت زیادہ پیدا ہوتے ہیں جب یہ عادات معمولات، کام، پڑھائی یا تعلقات پر حاوی ہونے لگیں۔',
      effectsTitle: 'بعض افراد کو درج ذیل چیلنجز کا سامنا ہو سکتا ہے:',
      effects: [
        'بار بار دہرائی جانے والی عادات یا خواہشات پر قابو پانے میں دشواری۔',
        'وقت کا ضیاع اور روزمرہ پیداواری صلاحیت میں کمی۔',
        'روزمرہ کی ذمہ داریوں پر توجہ مرکوز کرنے میں مشکل۔',
        'احساسِ ندامت، ذہنی دباؤ یا بے چینی و مایوسی کے جذبات۔',
        'تعلقات اور ازدواجی قربت کے بارے میں غیر حقیقی توقعات۔',
        'روزمرہ زندگی میں ایک صحت مند توازن برقرار رکھنے میں مشکلات۔',
      ],
      // Section 3
      whyVideosBadge: 'معلومات سے آگے کا قدم',
      whyVideosTitle: 'صرف ویڈیوز دیکھنا اور مضامین پڑھنا کافی کیوں نہیں ہو سکتا',
      whyVideosP1: 'مضامین پڑھنا اور تعلیمی ویڈیوز دیکھنا مفید معلومات اور عارضی حوصلہ افزائی تو فراہم کر سکتا ہے، لیکن بعض افراد کے لیے دہرائی جانے والی عادات کو توڑنے یا طویل مدتی تسلسل برقرار رکھنے کے لیے صرف معلومات کافی نہیں ہوتیں۔',
      whyVideosP2: 'حقیقی پیش رفت کے لیے محض ویڈیوز یا موٹیویشنل مواد سے آگے بڑھنے کی ضرورت ہوتی ہے۔ ایک احتسابی پارٹنر، ذاتی رہنمائی، باقاعدہ معاونت اور کسی ایسے شخص کا ساتھ جو آپ کے چیلنجز کو سمجھتا ہو، اس سفر کو بہت آسان بنا سکتا ہے۔',
      partnerTitle: 'ایک احتسابی پارٹنر آپ کی ان طریقوں سے مدد کر سکتا ہے:',
      partnerBenefits: [
        'اپنے ذاتی اہداف پر فوکس برقرار رکھنا۔',
        'محرکات (Triggers) کو پہچاننا اور اپنی عادات کو گہرائی سے سمجھنا۔',
        'تسلسل اور نظم و ضبط قائم رکھنا۔',
        'اپنی پیش رفت کا جائزہ لینا اور بغیر کسی شرمندگی کے ناکامیوں پر بات کرنا۔',
        'صحت مند معمولات اور مثبت عادات کی تعمیر کرنا۔',
      ],
      // Section 4
      personalMsgBadge: 'براہِ راست ذاتی پیغام',
      personalMsgTitle: 'آپ کو یہ جنگ تنہا لڑنے کی ضرورت نہیں ہے۔',
      personalMsgP1: 'بعض اوقات انسان کو صرف کسی ایسے شخص کی ضرورت ہوتی ہے جو اس کی مشکلات کو سمجھے، بغیر کسی ججمنٹ کے اس کی بات سنے، اور اسے احتساب کے دائرے میں رکھے۔',
      personalMsgP2: 'ہزاروں افراد کی رہنمائی کے 9 سالہ تجربے کے ساتھ، میں اپنے عملی فہم کو استعمال کر کے آپ کے نو فپ اہداف کے حصول میں آپ کی مدد کرنا چاہتا ہوں۔',
      personalMsgHighlight: 'آپ اکیلے نہیں ہیں۔ مثبت تبدیلی کی طرف پہلا قدم اٹھائیں۔',
      personalMsgCta: 'ذاتی رہنمائی حاصل کریں',
      // Section 5
      privacyBadge: 'محفوظ، پُراعتماد اور باوقار بات چیت',
      privacyTitle: 'آپ کی رازداری ہماری اولین ترجیح ہے۔',
      privacyP1: 'ہم سمجھتے ہیں کہ ذاتی عادات اور نجی مسائل پر بات کرنا کتنا مشکل ہو سکتا ہے۔ بلا جھجھک رابطہ کریں۔ آپ کی رازداری اور ذاتی معلومات کا احترام، احتیاط اور مکمل رازداری کے ساتھ خیال رکھا جاتا ہے۔',
      privacyP2: 'آپ بغیر کسی شرمندگی یا فیصلے کے خوف کے اپنی بات شیئر کر سکتے ہیں۔ آپ کا ذاتی سفر فہم، عزت اور رازداری کا مستحق ہے۔',
      privacyHighlight: 'محفوظ محسوس کریں۔ کھل کر بات کریں۔ آپ کی رازداری ہمارے لیے مقدم ہے۔',
      privacyPracticeNote: 'آپ کی تمام بات چیت صرف براہِ راست رہنمائی کے مقصد کے لیے واٹس ایپ اور ای میل پر محفوظ و باوقار رکھی جاتی ہے۔',
    },
    accountability: {
      badge: 'صرف معلومات سے آگے',
      heading: 'کبھی کبھی، صرف معلومات کافی نہیں ہوتیں۔',
      p1: 'شاید آپ نے بے شمار ویڈیوز دیکھی ہوں، مضامین پڑھے ہوں اور اپنی عادات بدلنے کی کئی بار کوشش کی ہو۔ لیکن بعض اوقات، آپ خود کو دوبارہ پرانے راستوں پر واپس پاتے ہیں۔',
      p2: 'یہ وہ مقام ہے جہاں ذاتی رہنمائی اور باقاعدہ احتساب آپ کی حقیقی مدد کر سکتا ہے۔',
      p3: 'کسی ایسے شخص کا ساتھ جو قدم بہ قدم آپ کی رہنمائی کرے، آپ کے مسائل سنے اور آپ کو فوکسڈ رکھے، آپ کے سفر کو منظم اور کامیاب بناتا ہے۔',
      highlight: 'صرف ویڈیوز نہ دیکھیں۔ ذاتی رہنمائی کے ساتھ عملی قدم اٹھائیں۔',
    },
    guidancePlans: {
      badge: 'آسان اور لچکدار ون ٹو ون معاونت',
      heading: 'ون ٹو ون ذاتی رہنمائی',
      description: 'ہر فرد کا سفر مختلف ہوتا ہے۔ وہ دورانیہ منتخب کریں جو آپ کے لیے سب سے زیادہ موزوں ہو۔',
      discussionNote: 'پلان کی مزید تفصیلات اور آغاز کے لیے براہِ راست مجھ سے واٹس ایپ پر رابطہ کریں۔ 100% رازدارانہ۔',
      plans: {
        weekly: {
          title: 'ہفتہ وار رہنمائی',
          duration: '7 دن کی معاونت',
          description: 'ہفتہ وار بنیادوں پر ذاتی ون ٹو ون رہنمائی اور احتسابی معاونت۔',
          buttonText: 'ہفتہ وار پلان منتخب کریں',
          whatsappMessage: 'السلام علیکم وسیم بھائی، مجھے آپ کے ہفتہ وار ون ٹو ون پرسنل گائیڈنس پلان میں دلچسپی ہے۔ براہ کرم تفصیلات فراہم کریں۔',
        },
        fifteen: {
          title: '15-DAY رہنمائی',
          duration: '15 دن کی معاونت',
          description: '15 دنوں کے لیے مسلسل ذاتی رہنمائی اور احتسابی معاونت۔',
          buttonText: '15 روزہ پلان منتخب کریں',
          whatsappMessage: 'السلام علیکم وسیم بھائی، مجھے آپ کے 15 روزہ ون ٹو ون پرسنل گائیڈنس پلان میں دلچسپی ہے۔ براہ کرم تفصیلات فراہم کریں۔',
        },
        monthly: {
          title: 'ماہانہ رہنمائی',
          duration: '1 ماہ کی مکمل معاونت',
          description: 'ایک ماہ کے لیے وسیع ون ٹو ون ذاتی رہنمائی اور گہری احتسابی معاونت۔',
          buttonText: 'ماہانہ پلان منتخب کریں',
          whatsappMessage: 'السلام علیکم وسیم بھائی، مجھے آپ کے ماہانہ ون ٹو ون پرسنل گائیڈنس پلان میں دلچسپی ہے۔ براہ کرم تفصیلات فراہم کریں۔',
        },
      },
    },
    milestones: {
      badge: 'بحالی کا بصری نقشہ',
      title: 'پیش رفت کے اہم مراحل: عادات کی تبدیلی کے عام درجات',
      subheading: 'عادات کی ازسرنو تعمیر، خواہشات پر قابو اور پائیدار خود ضابطگی کے سفر کی رہنمائی کے لیے ایک آسان بصری روڈ میپ۔',
      note: 'حقیقت پسندانہ یاددہانی: یہ سفر ہمیشہ سیدھی لکیر کی طرح نہیں ہوتا۔ کبھی کبھار کی پھسلن کا مطلب مکمل ناکامی نہیں بلکہ سیکھنے کا موقع ہوتا ہے۔ باقاعدہ رہنمائی ہر موڑ پر استقامت فراہم کرتی ہے۔',
      roadmapCta: 'کیا آپ جاننا چاہتے ہیں کہ آپ اس وقت کس مرحلے پر ہیں؟ رہنمائی کے لیے واٹس ایپ پر رابطہ کریں۔',
      stages: [
        {
          stageNumber: '01',
          days: 'دن 1 تا 7',
          title: 'غیر شعوری عادت کے دائرے کو توڑنا',
          focus: 'فوری محرکات (Triggers) کو پہچاننا، موبائل فون اور رات کے اوقات کے لیے حدود قائم کرنا، اور خودکار عادات کو بریک لگانا۔',
          experience: 'بے چینی، بار بار پرانی عادت کی طرف میلان، اور فارغ اوقات میں پرانے معمولات کی طرف دماغ کا کھنچاؤ۔',
          guidanceSupport: 'ابتدائی دنوں کے دباؤ کو سنبھالنے اور خود کو مستحکم رکھنے کے لیے روزانہ صبح و شام احتساب۔',
        },
        {
          stageNumber: '02',
          days: 'دن 8 تا 21',
          title: 'معمولات کی ازسرنو ترتیب اور خواہشات پر قابو',
          focus: 'اسکرین کے فضول استعمال کی جگہ ورزش، باقاعدہ نیند اور خواہشات کا رخ مثبت سرگرمیوں کی طرف موڑنا۔',
          experience: 'عارضی بے کیفی (Dopamine Drop)، اکتاہٹ اور مزاج میں اتار چڑھاؤ کیونکہ ذہن قدرتی تحریک پر واپس لوٹ رہا ہوتا ہے۔',
          guidanceSupport: 'غیر جانبدارانہ احتساب تاکہ کمزور لمحات میں غلط فیصلوں کے جواز تراشنے سے بچا جا سکے۔',
        },
        {
          stageNumber: '03',
          days: 'دن 22 تا 45',
          title: 'جمود (Flatline) سے نپٹنا اور مستقل مزاجی',
          focus: 'ابتدائی جوش مدہم پڑنے کے بعد بھی نظم و ضبط قائم رکھنا اور عارضی بے حسی یا سستی کا صبر سے سامنا کرنا۔',
          experience: 'توانائی کی وقتی کمی، جذبات میں کمی (Flatline)، اور یہ شک کہ کیا واقعی بہتری آ رہی ہے یا نہیں۔',
          guidanceSupport: 'پرسکون تسلی اور ایک تجربہ کار گائیڈ کی رہنمائی جس نے ہزاروں لوگوں کو اس مرحلے سے باحفاظت نکالا ہو۔',
        },
        {
          stageNumber: '04',
          days: 'دن 46 تا 90+',
          title: 'پائیدار نظم و ضبط اور نئی شخصیت کی تعمیر',
          focus: 'صحت مند عادات کو پختہ کرنا، عزتِ نفس کی مکمل بحالی اور مستقبل میں پھسلن سے بچاؤ کے اصول قائم کرنا۔',
          experience: 'بہترین ذہنی یکسوئی، رشتوں میں باوقار حاضری، قدرتی توانائی میں اضافہ اور خود پر دوبارہ غیر متزلزل اعتماد۔',
          guidanceSupport: 'طویل مدتی عادات کی بقا اور زندگی میں مسلسل مثبت ترقی کے لیے رہنمائی۔',
        },
      ],
    },
    testimonials: {
      badge: 'حقیقی اثرات · شناخت مخفی رکھی گئی ہے',
      title: 'عادات بدلنے اور ذاتی رہنمائی کی کامیاب کہانیاں',
      subheading: 'ان افراد کے حقیقی تجربات جنہوں نے باقاعدہ ون ٹو ون رہنمائی اور احتساب کی مدد سے بار بار دہرائی جانے والی منفی عادات پر قابو پایا۔',
      privacyNotice: 'کلائنٹس کی رازداری کا تحفظ: تمام نام، مقامات اور ذاتی شناخت کو مکمل طور پر مخفی رکھا گیا ہے۔ یہ کہانیاں نان کلینیکل رہنمائی اور احتساب کے حقیقی نتائج کی عکاسی کرتی ہیں۔',
      stories: [
        {
          tag: 'کارپوریٹ پروفیشنل · شناخت مخفی',
          milestone: '2 ہفتوں کے دائرے سے نجات · اب 5 ماہ سے مسلسل پاک',
          quote: 'میں چار سال تک اسی چکر میں پھنسا رہا—ہر 10 سے 14 دن بعد دوبارہ اسی عادت کا شکار ہو جاتا اور مایوس ہو جاتا۔ اصل تبدیلی تب آئی جب روزانہ صبح و شام احتساب کے لیے ایک حقیقی گائیڈ موجود تھا۔ محرکات پر کھل کر بات کرنے نے تنہائی اور شرمندگی کا بوجھ ختم کر دیا۔',
          keyTakeaway: 'روزانہ کے احتساب نے محض کھوکھلے ارادوں کی جگہ ایک منظم ضابطہ قائم کیا۔',
          impactArea: 'پیشہ ورانہ توجہ اور خود ضابطگی',
        },
        {
          tag: 'یونیورسٹی طالب علم · شناخت مخفی',
          milestone: 'دیر رات کی کمزوریوں پر قابو · 90 روزہ چیلنج مکمل',
          quote: 'میری سب سے بڑی کمزوری کمرے میں اکیلے رات گئے پڑھائی کے دوران فون پاس رکھنا تھی۔ وسیم بھائی کی غیر جانبدارانہ رہنمائی نے بغیر کسی احساسِ جرم کے میرے سونے کے اوقات اور معمولات کو تبدیل کرنے میں مدد کی۔ میرا ارتکاز بحال ہوا اور امتحانات کے نتائج شاندار رہے۔',
          keyTakeaway: 'محض زبردستی روکنے کے بجائے صحت مند معمولات کو زندگی کا حصہ بنایا۔',
          impactArea: 'ذہنی یکسوئی اور پرسکون نیند',
        },
        {
          tag: 'بین الاقوامی کلائنٹ · شناخت مخفی',
          milestone: 'ایک پھسلن کے بعد مسلسل ناکامی کا خاتمہ',
          quote: 'ماضی میں جب بھی مجھ سے غلطی ہوتی، شدید خود نفرت کی وجہ سے میں کئی ہفتوں تک لگاتار منفی عادات میں ڈوب جاتا۔ وسیم بھائی کی رہنمائی میں، میں نے پرسکون رہ کر محرکات کا تجزیہ کرنا سیکھا۔ ناکامی کے بعد فوری سنبھلنا ہی اصل کامیابی ثابت ہوا۔',
          keyTakeaway: 'ناکامی کو پرسکون انداز میں سنبھالنے کے فن نے طویل مایوسی سے بچا لیا۔',
          impactArea: 'جذباتی استحکام و پختگی',
        },
        {
          tag: 'خاندانی اور برسرِ روزگار فرد · شناخت مخفی',
          milestone: 'خفیہ عادات کا خاتمہ اور ذہنی دھند سے نجات · 6 ماہ',
          quote: 'خفیہ عادات اور مسلسل ذہنی دھند نے میری تمام تر توانائی چھین لی تھی۔ باقاعدہ رہنمائی نے مجھے بغیر کسی غلط عادت کے دفتری دباؤ کو سنبھالنے کے عملی طریقے سکھائے۔ اب میں اپنے خاندان کے ساتھ ذہنی طور پر مکمل حاضر محسوس کرتا ہوں۔',
          keyTakeaway: 'چھپی ہوئی عادت کے خاتمے نے عزتِ نفس اور خاندانی سکون لوٹا دیا۔',
          impactArea: 'خاندانی سکون اور عزتِ نفس',
        },
      ],
      ctaText: 'آپ کا سفر بھی ذاتی رہنمائی، صبر اور بغیر کسی طعنے یا فیصلے کے ہمدردی کا مستحق ہے۔',
      ctaButton: 'وسیم بھائی سے واٹس ایپ پر بات کریں',
    },
    contact: {
      badge: 'براہِ راست رابطہ و رہنمائی',
      heading: 'آزادی کے سفر کے لیے تیار ہیں؟ مجھ سے رابطہ کریں۔',
      subheading: 'رہنمائی پر بات کرنے، سوالات پوچھنے یا اپنے احتسابی پلان کے آغاز کے لیے براہِ راست رابطہ کریں۔',
      nameLabel: 'گائیڈ و بانی',
      nameValue: 'وسیم عباس (Waseem Abbas)',
      emailLabel: 'سرکاری ای میل',
      emailValue: FOUNDER_EMAIL,
      whatsappButton: 'مجھ سے واٹس ایپ پر رابطہ کریں',
      emailButton: 'ای میل ارسال کریں',
      phoneNumber: OFFICIAL_PHONE,
      availability: 'دنیا بھر کے بین الاقوامی کلائنٹس کے لیے دستیاب · مکمل رازداری کی ضمانت',
      coreMessage: 'آپ اکیلے نہیں ہیں۔ ذاتی رہنمائی صرف ایک کلک کے فاصلے پر ہے۔',
      privacyAssurance: 'آپ کی رازداری ہماری اولین ترجیح ہے۔ بغیر کسی جھجک کے بات کریں۔',
    },
    footer: {
      tagline: 'لوگوں کو صحت مند عادات اور بہتر زندگی کی تعمیر میں مددگار۔',
      founderLabel: 'ذاتی گائیڈ:',
      founderName: 'وسیم عباس (Waseem Abbas)',
      emailLabel: 'براہِ راست ای میل:',
      emailValue: FOUNDER_EMAIL,
      contactLabel: 'آفیشل واٹس ایپ:',
      disclaimer: 'نو فپ ہیلتھ (NoFap Health) تعلیمی معلومات اور غیر طبی ذاتی رہنمائی فراہم کرتا ہے۔ یہ کوئی میڈیکل یا دماغی صحت کا کلینک نہیں ہے اور پیشہ ورانہ طبی مشورے کا نعم البدل نہیں۔',
      copyright: 'نو فپ ہیلتھ۔ ذاتی آزادی اور خود ضابطگی کے لیے وقف۔',
      rights: 'تمام حقوق محفوظ ہیں۔',
    },
    floatingButtonTooltip: 'واٹس ایپ پر رابطہ کریں',
    prefilledWhatsAppMessage: 'السلام علیکم وسیم بھائی، میں نے NoFap Health ویب سائٹ دیکھی ہے اور مجھے آپ کے ذاتی رہنمائی پلان میں دلچسپی ہے۔ براہ کرم مزید تفصیلات فراہم کریں۔',
  },
};

export function getWhatsAppUrl(lang: Language = 'en'): string {
  const message = TRANSLATIONS[lang].prefilledWhatsAppMessage;
  return `${OFFICIAL_WHATSAPP_BASE}?text=${encodeURIComponent(message)}`;
}

export type PlanKey = 'weekly' | 'fifteen' | 'monthly';

export function getPlanWhatsAppUrl(planKey: PlanKey, lang: Language = 'en'): string {
  const message = TRANSLATIONS[lang].guidancePlans.plans[planKey].whatsappMessage;
  return `${OFFICIAL_WHATSAPP_BASE}?text=${encodeURIComponent(message)}`;
}
