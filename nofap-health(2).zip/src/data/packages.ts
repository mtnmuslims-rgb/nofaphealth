import { GuidancePackage } from '../types';

export const GUIDANCE_PACKAGES: GuidancePackage[] = [
  {
    id: 'single-deep-dive',
    title: '1-on-1 Foundation Reset Session',
    badge: 'Single Deep-Dive',
    tagline: 'A comprehensive 75-minute consultation to map your specific triggers, dissect previous relapse cycles, and build a personalized action blueprint.',
    duration: '75 Minutes Consultation',
    idealFor: 'Individuals stuck in repetitive relapse loops who need an objective, experienced perspective to diagnose their blind spots.',
    format: 'Private Video or Voice Call (Zoom / Google Meet / Signal / Telegram)',
    features: [
      'Comprehensive audit of your personal triggers & daily schedule',
      'Digital environment & friction setup recommendations',
      'Customized emergency urge protocol tailored to your living situation',
      'Follow-up summary PDF with your customized action blueprint',
      '7 days of post-session text check-in support'
    ],
    deliverables: [
      'Personal Trigger Map & High-Risk Time Analysis',
      'Customized 15-Minute Urge Management Protocol',
      'Device Friction & Bedtime Lockdown Checklist'
    ]
  },
  {
    id: 'monthly-accountability',
    title: 'Weekly Accountability Partnership',
    badge: 'Most Comprehensive',
    tagline: '4 Weeks of structured, continuous guidance and direct accountability to break past your plateau and establish enduring habits.',
    duration: '4-Week Intensive Program',
    idealFor: 'Anyone who knows the theory but struggles with execution when stress, solitude, or fatigue hits during the week.',
    format: 'Weekly 1-on-1 Calls + Direct Mid-Week Text Accountability',
    features: [
      '4 x 50-Minute private weekly strategy & reflection sessions',
      'Dedicated direct messaging access (Monday–Friday) for real-time check-ins',
      'Weekly habit & trigger log review to calibrate strategies',
      'Emergency SOS text support during acute urge waves',
      'Lifestyle restructuring: sleep routines, physical training & focus hours',
      '100% confidential, non-judgmental, honest peer mentorship'
    ],
    deliverables: [
      'Weekly Habit Calibration & Progress Scorecard',
      'Personalized Evening Shutdown Protocol',
      'SOS Hotline Support During Acute Vulnerability Waves',
      'End-of-Month Long-Term Continuity Strategy'
    ]
  },
  {
    id: 'quarterly-rebuild',
    title: '3-Month Complete Lifestyle Rebuild',
    badge: 'Total Transformation',
    tagline: '12 Weeks of dedicated partnership to fully rewire habits, restore self-discipline, and rebuild your life with confidence.',
    duration: '12-Week Transformational Program',
    idealFor: 'Committed individuals who want to completely replace compulsive coping mechanisms with high-performance discipline and deep emotional resilience.',
    format: '12 Weekly 1-on-1 Calls + Priority Daily Accountability',
    features: [
      '12 x 50-Minute deep-dive mentorship sessions',
      'Priority continuous messaging accountability throughout the entire 90 days',
      'Detailed navigation through the flatline and neurochemical recalibration',
      'Identity shift: transitioning from "struggling addict" to self-disciplined man',
      'Deep work routines, fitness integration, and social confidence building',
      'Comprehensive long-term relapse-proofing system'
    ],
    deliverables: [
      'Complete 90-Day Neuro-Rewiring Milestone Roadmap',
      'Weekly In-Depth Progress Audits & Schedule Optimization',
      'Lifelong Relapse-Proofing & Lifestyle Maintenance Manual'
    ]
  }
];
