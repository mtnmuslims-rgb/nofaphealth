import React from 'react';
import { GUIDANCE_PACKAGES } from '../data/packages';
import { Check, Calendar, ArrowRight, ShieldCheck, Clock } from 'lucide-react';
import { GuidancePackage } from '../types';

interface ServicesSectionProps {
  onSelectPackage: (pkg: GuidancePackage) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectPackage }) => {
  return (
    <section id="guidance" className="py-20 lg:py-28 bg-[#081226] border-b border-blue-950/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <span className="text-xs font-semibold tracking-wider uppercase text-emerald-400 font-mono">
            PERSONAL GUIDANCE & ACCOUNTABILITY
          </span>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight [text-wrap:balance]">
            Structured Support Built for Real Life
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-200">
            Real guidance. Personal support. A better you. Choose the level of mentorship that fits your current challenges and goals.
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-blue-500 via-[#facc15] to-emerald-400 mx-auto mt-4 rounded-full" />
        </div>

        {/* Packages Grid */}
        <div className="mt-16 grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {GUIDANCE_PACKAGES.map((pkg, idx) => {
            const isFeatured = idx === 1;

            return (
              <div
                key={pkg.id}
                className={`relative rounded-2xl flex flex-col justify-between transition-all duration-300 ${
                  isFeatured
                    ? 'bg-gradient-to-b from-[#0e214a] to-[#0a1835] border-2 border-[#facc15] shadow-2xl shadow-blue-950/80 lg:-translate-y-2'
                    : 'bg-[#0c1a36]/70 border border-blue-900/60 hover:border-blue-700/80'
                }`}
              >
                {/* Featured Badge */}
                {pkg.badge && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                    <span className={`px-3.5 py-1 text-xs font-bold rounded-full uppercase tracking-wider ${
                      isFeatured 
                        ? 'bg-gradient-to-r from-[#facc15] to-[#eab308] text-slate-950 shadow-md border border-amber-300/60' 
                        : 'bg-blue-900/80 text-blue-200 border border-blue-700/60'
                    }`}>
                      {pkg.badge}
                    </span>
                  </div>
                )}

                <div className="p-6 sm:p-8 flex-1">
                  
                  {/* Title & Tagline */}
                  <div className="pt-2">
                    <h3 className="text-xl sm:text-2xl font-bold text-white">
                      {pkg.title}
                    </h3>
                    <p className="mt-3 text-sm text-slate-300 leading-relaxed">
                      {pkg.tagline}
                    </p>
                  </div>

                  {/* Format & Duration Meta */}
                  <div className="mt-6 pt-6 border-t border-blue-900/60 space-y-2.5 text-xs text-slate-300">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-[#facc15] shrink-0" />
                      <span className="font-semibold text-white">{pkg.duration}</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <Calendar className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{pkg.format}</span>
                    </div>
                  </div>

                  {/* Ideal For */}
                  <div className="mt-5 p-3.5 rounded-xl bg-[#060e20]/80 border border-blue-900/50">
                    <span className="text-[11px] uppercase tracking-wider text-emerald-400 font-mono font-semibold block mb-1">
                      Ideal For
                    </span>
                    <p className="text-xs text-slate-300 leading-normal">
                      {pkg.idealFor}
                    </p>
                  </div>

                  {/* Key Features */}
                  <div className="mt-6">
                    <span className="text-xs uppercase font-semibold text-slate-200 tracking-wider block mb-3 font-mono">
                      What is Included:
                    </span>
                    <ul className="space-y-2.5">
                      {pkg.features.map((feature, fIdx) => (
                        <li key={fIdx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-200">
                          <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                </div>

                {/* Bottom CTA Area */}
                <div className="p-6 sm:p-8 pt-0">
                  <button
                    onClick={() => onSelectPackage(pkg)}
                    className={`w-full py-3.5 px-4 rounded-xl font-extrabold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md ${
                      isFeatured
                        ? 'bg-gradient-to-r from-[#facc15] to-[#eab308] text-slate-950 hover:from-amber-300 hover:to-amber-400 border border-amber-300/50'
                        : 'bg-[#10244c] text-white hover:bg-blue-900/80 border border-blue-700/60'
                    }`}
                  >
                    <span>Request This Guidance</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <p className="mt-2 text-center text-[11px] text-slate-400">
                    100% confidential · Non-judgmental consultation
                  </p>
                </div>

              </div>
            );
          })}
        </div>

        {/* Reassurance Banner */}
        <div className="mt-14 max-w-3xl mx-auto p-4 rounded-xl bg-[#0c1a36]/80 border border-blue-900/60 flex items-center gap-3.5">
          <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
          <p className="text-xs sm:text-sm text-slate-200">
            <strong>Unsure which option fits your needs?</strong> You can schedule an initial introductory call or submit an inquiry with zero obligation. We only accept clients whom we are confident we can meaningfully help.
          </p>
        </div>

      </div>
    </section>
  );
};
