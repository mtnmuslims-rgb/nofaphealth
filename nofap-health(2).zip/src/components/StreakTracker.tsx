import React, { useState, useEffect } from 'react';
import { Calendar, Shield, Award, RotateCcw, Plus, Trash2, CheckCircle2, Lock } from 'lucide-react';
import { RelapseLog } from '../types';

export const StreakTracker: React.FC = () => {
  const [startDateStr, setStartDateStr] = useState<string>(() => {
    return localStorage.getItem('nofap_start_date') || new Date().toISOString();
  });

  const [daysClean, setDaysClean] = useState<number>(0);
  const [hoursClean, setHoursClean] = useState<number>(0);
  const [showLogModal, setShowLogModal] = useState<boolean>(false);

  // Relapse logs
  const [logs, setLogs] = useState<RelapseLog[]>(() => {
    const saved = localStorage.getItem('nofap_relapse_logs');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return [];
      }
    }
    return [
      {
        id: '1',
        date: '2026-10-28',
        trigger: 'Phone in bedroom late at night',
        timeOfDay: '11:45 PM',
        notes: 'Was tired after stressful work day, started browsing social media in bed.',
        recoveryAction: 'Moved phone charger to the kitchen permanently.'
      }
    ];
  });

  // Form states for adding a reflection log
  const [logTrigger, setLogTrigger] = useState<string>('Phone in bedroom late at night');
  const [logTime, setLogTime] = useState<string>('Late Night');
  const [logNotes, setLogNotes] = useState<string>('');
  const [logRecovery, setLogRecovery] = useState<string>('');

  // Calculate clean time
  useEffect(() => {
    const updateTime = () => {
      const start = new Date(startDateStr).getTime();
      const now = new Date().getTime();
      const diff = Math.max(0, now - start);

      const d = Math.floor(diff / (1000 * 60 * 60 * 24));
      const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

      setDaysClean(d);
      setHoursClean(h);
    };

    updateTime();
    const interval = setInterval(updateTime, 60000);
    return () => clearInterval(interval);
  }, [startDateStr]);

  // Save changes to localStorage
  const handleSetStartToday = () => {
    const nowStr = new Date().toISOString();
    setStartDateStr(nowStr);
    localStorage.setItem('nofap_start_date', nowStr);
  };

  const handleCustomStartDate = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    if (val) {
      const dateObj = new Date(val);
      const iso = dateObj.toISOString();
      setStartDateStr(iso);
      localStorage.setItem('nofap_start_date', iso);
    }
  };

  const handleAddLog = (e: React.FormEvent) => {
    e.preventDefault();
    const newLog: RelapseLog = {
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      trigger: logTrigger,
      timeOfDay: logTime,
      notes: logNotes || 'Momentary lapse in environment discipline.',
      recoveryAction: logRecovery || 'Reinforce evening shutdown protocol.'
    };

    const updated = [newLog, ...logs];
    setLogs(updated);
    localStorage.setItem('nofap_relapse_logs', JSON.stringify(updated));

    // Reset clean streak start to right now without shame
    handleSetStartToday();
    setShowLogModal(false);
    setLogNotes('');
    setLogRecovery('');
  };

  const handleDeleteLog = (id: string) => {
    const updated = logs.filter((l) => l.id !== id);
    setLogs(updated);
    localStorage.setItem('nofap_relapse_logs', JSON.stringify(updated));
  };

  const milestones = [
    { day: 1, label: 'Day 1: Acute Withdrawal' },
    { day: 3, label: 'Day 3: The 72-Hour Ridge' },
    { day: 7, label: 'Day 7: First Clean Week' },
    { day: 14, label: 'Day 14: Two-Week Horizon' },
    { day: 30, label: 'Day 30: Receptor Upregulation' },
    { day: 60, label: 'Day 60: Cognitive Clarity' },
    { day: 90, label: 'Day 90: Neuro-Rewiring Milestone' },
  ];

  return (
    <section className="py-20 lg:py-28 bg-[#081226] border-b border-blue-950/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#0c1a36] border border-blue-800 text-slate-200 text-xs font-semibold uppercase tracking-wider mb-3">
            <Lock className="w-3.5 h-3.5 text-[#facc15]" />
            <span>100% Client-Side & Private (Saved Only on Your Device)</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight [text-wrap:balance]">
            Clean Streak & Honest Habit Reflection
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-200">
            Progress is not a straight line. Track your clean days, view milestones, and record slips as clinical learning data rather than moral failures.
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-blue-500 via-[#facc15] to-emerald-400 mx-auto mt-4 rounded-full" />
        </div>

        {/* Counter Display & Actions */}
        <div className="mt-14 max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-stretch">
          
          {/* Main Streak Counter Card */}
          <div className="md:col-span-7 rounded-3xl bg-gradient-to-br from-[#0e214a] via-[#0a1937] to-[#061026] border border-blue-800/80 p-8 flex flex-col justify-between shadow-2xl">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-mono tracking-wider text-emerald-400 font-semibold">
                  Current Clean Streak
                </span>
                <span className="text-xs font-bold text-emerald-400 bg-emerald-950/80 border border-emerald-600/60 px-3 py-1 rounded-full">
                  Active
                </span>
              </div>

              <div className="mt-6 flex items-baseline gap-4">
                <div className="text-6xl sm:text-7xl font-black text-white font-mono tracking-tight tabular-nums drop-shadow-md">
                  {daysClean}
                </div>
                <div>
                  <div className="text-xl sm:text-2xl font-black text-[#facc15]">
                    {daysClean === 1 ? 'Day Clean' : 'Days Clean'}
                  </div>
                  <div className="text-xs text-slate-300 font-mono tabular-nums">
                    + {hoursClean} {hoursClean === 1 ? 'hour' : 'hours'}
                  </div>
                </div>
              </div>

              <p className="mt-6 text-xs sm:text-sm text-slate-200 leading-relaxed">
                {daysClean < 3
                  ? 'The first 72 hours are the highest friction. Stay physically active and keep your devices outside your sleeping area.'
                  : daysClean < 7
                  ? 'You are building real momentum. Notice how your sleep quality and morning energy are beginning to shift.'
                  : daysClean < 30
                  ? 'Excellent consistency. Beware of complacency; keep your digital friction guards strictly active.'
                  : 'Remarkable dedication. Your prefrontal regulation and dopamine receptor density are significantly recalibrating.'}
              </p>
            </div>

            {/* Streak Controls */}
            <div className="mt-8 pt-6 border-t border-blue-900/60 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-slate-300" />
                <span className="text-xs text-slate-300">Start Date:</span>
                <input
                  type="date"
                  value={startDateStr.split('T')[0]}
                  onChange={handleCustomStartDate}
                  className="bg-[#060e20] border border-blue-800 text-xs text-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#facc15]"
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleSetStartToday}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#10244c] hover:bg-blue-900/80 text-slate-200 transition-colors cursor-pointer border border-blue-800/60"
                  title="Reset counter to today without a journal log"
                >
                  <RotateCcw className="w-3.5 h-3.5 inline mr-1 text-[#facc15]" />
                  Reset Today
                </button>
                <button
                  onClick={() => setShowLogModal(true)}
                  className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-rose-950/70 text-rose-300 border border-rose-800 hover:bg-rose-900/60 transition-colors cursor-pointer"
                >
                  Log a Slip (Without Shame)
                </button>
              </div>
            </div>
          </div>

          {/* Milestones Card */}
          <div className="md:col-span-5 rounded-3xl bg-[#0c1a36]/80 border border-blue-900/60 p-6 flex flex-col justify-between shadow-xl">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Award className="w-5 h-5 text-[#facc15]" />
                <h3 className="text-base font-bold text-white">Milestone Roadmap</h3>
              </div>

              <div className="space-y-2.5">
                {milestones.map((m) => {
                  const isReached = daysClean >= m.day;
                  return (
                    <div
                      key={m.day}
                      className={`p-2.5 rounded-xl border text-xs flex items-center justify-between transition-colors ${
                        isReached
                          ? 'bg-amber-400/15 border-amber-400/50 text-[#facc15]'
                          : 'bg-[#060e20]/60 border-blue-950 text-slate-400'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        {isReached ? (
                          <CheckCircle2 className="w-4 h-4 text-[#facc15] shrink-0" />
                        ) : (
                          <div className="w-4 h-4 rounded-full border border-slate-700 shrink-0" />
                        )}
                        <span className={isReached ? 'font-bold text-white' : ''}>
                          {m.label}
                        </span>
                      </div>
                      <span className="font-mono text-[11px] font-semibold">
                        {isReached ? 'Unlocked' : `${m.day}d`}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            <p className="mt-4 text-[11px] text-slate-400 italic">
              Milestones mark physiological phases, not finish lines. Freedom is a daily standard.
            </p>
          </div>

        </div>

        {/* Relapse Reflection Log Section */}
        <div className="mt-12 max-w-4xl mx-auto">
          <div className="p-6 rounded-2xl bg-slate-900/40 border border-slate-800">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-bold text-white">
                  Post-Slip Diagnostic Journal
                </h3>
                <p className="text-xs text-slate-400">
                  Every slip has an environmental or emotional anatomy. Write down the facts, seal the leak, and keep moving forward.
                </p>
              </div>
              <button
                onClick={() => setShowLogModal(true)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-400 text-slate-950 hover:bg-amber-300 transition-colors flex items-center gap-1 cursor-pointer shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Reflection</span>
              </button>
            </div>

            {logs.length === 0 ? (
              <p className="text-xs text-slate-500 py-4 text-center">
                No slips logged. Stay vigilant and keep daily friction active.
              </p>
            ) : (
              <div className="space-y-3">
                {logs.map((log) => (
                  <div
                    key={log.id}
                    className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col sm:flex-row sm:items-start justify-between gap-4"
                  >
                    <div className="space-y-1.5">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs font-mono font-semibold text-amber-400">
                          {log.date}
                        </span>
                        <span className="text-slate-600">·</span>
                        <span className="text-xs text-slate-400">
                          {log.timeOfDay}
                        </span>
                        <span className="text-slate-600">·</span>
                        <span className="text-xs font-medium text-rose-300 bg-rose-950/50 px-2 py-0.5 rounded">
                          Trigger: {log.trigger}
                        </span>
                      </div>
                      <p className="text-xs sm:text-sm text-slate-300">
                        {log.notes}
                      </p>
                      <div className="text-xs text-emerald-300 flex items-center gap-1.5 pt-1">
                        <Shield className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>Action Taken: {log.recoveryAction}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDeleteLog(log.id)}
                      className="text-slate-500 hover:text-rose-400 transition-colors p-1 cursor-pointer self-end sm:self-start"
                      title="Delete log"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Modal for Logging a Slip */}
        {showLogModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
            <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-6">
              
              <div>
                <h3 className="text-xl font-bold text-white">
                  Log a Slip (Zero Shame, 100% Truth)
                </h3>
                <p className="mt-1 text-xs text-slate-400 leading-relaxed">
                  Take a slow, deep breath. You are safe. This is not a failure of your character; it is a breakdown of your friction system. Let&apos;s diagnose what happened so it never repeats.
                </p>
              </div>

              <form onSubmit={handleAddLog} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5 font-mono">
                    Primary Trigger
                  </label>
                  <select
                    value={logTrigger}
                    onChange={(e) => setLogTrigger(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-sm text-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:border-amber-400"
                  >
                    <option value="Phone in bedroom late at night">Phone in bedroom late at night</option>
                    <option value="Work / Academic Stress">High stress / Cognitive fatigue</option>
                    <option value="Boredom / Empty afternoon">Boredom & unstructured solitude</option>
                    <option value="Peeking on social media">Social media browsing / Peeking</option>
                    <option value="Emotional loneliness">Loneliness or relationship conflict</option>
                    <option value="Alcohol / Hangover">Alcohol or lowered inhibitions</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5 font-mono">
                    Approximate Time of Day
                  </label>
                  <input
                    type="text"
                    value={logTime}
                    onChange={(e) => setLogTime(e.target.value)}
                    placeholder="e.g., 11:30 PM, Sunday afternoon"
                    className="w-full bg-slate-950 border border-slate-800 text-sm text-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5 font-mono">
                    Honest Reflection: What led up to this?
                  </label>
                  <textarea
                    rows={3}
                    value={logNotes}
                    onChange={(e) => setLogNotes(e.target.value)}
                    placeholder="Be precise: Where was your computer? Were you in bed? What were you feeling 30 minutes before?"
                    className="w-full bg-slate-950 border border-slate-800 text-sm text-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5 font-mono">
                    New Friction / Corrective Action
                  </label>
                  <input
                    type="text"
                    value={logRecovery}
                    onChange={(e) => setLogRecovery(e.target.value)}
                    placeholder="e.g. Move router timer to shut off at 10 PM; buy analog alarm"
                    className="w-full bg-slate-950 border border-slate-800 text-sm text-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setShowLogModal(false)}
                    className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer"
                  >
                    Save & Reset Counter With Honor
                  </button>
                </div>
              </form>

            </div>
          </div>
        )}

      </div>
    </section>
  );
};
