import React from 'react';
import { Language, TRANSLATIONS, getWhatsAppUrl } from '../data/translations';
import { 
  Quote, 
  ShieldCheck, 
  CheckCircle2, 
  MessageCircle, 
  ArrowRight, 
  Sparkles,
  Lock,
  TrendingUp,
  UserCheck
} from 'lucide-react';

interface TestimonialsSectionProps {
  currentLang: Language;
}

export const TestimonialsSection: React.FC<TestimonialsSectionProps> = ({ currentLang }) => {
  const t = TRANSLATIONS[currentLang];
  const test = t.testimonials;
  const whatsappUrl = getWhatsAppUrl(currentLang);
  const isRTL = currentLang === 'ur';

  return (
    <section id="testimonials" className="py-16 lg:py-24 bg-[#081226] border-b border-blue-950/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-wider uppercase text-emerald-400 font-mono bg-emerald-950/40 border border-emerald-800/40 px-3 py-1 rounded-full">
            <Sparkles className="w-3.5 h-3.5 text-[#facc15]" />
            {test.badge}
          </span>
          <h2 className="mt-3 text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight [text-wrap:balance]">
            {test.title}
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-500 via-[#facc15] to-emerald-400 mx-auto mt-4 rounded-full" />
          
          <p className="mt-4 text-base sm:text-lg text-slate-300 leading-relaxed font-normal">
            {test.subheading}
          </p>
        </div>

        {/* Testimonials Grid (2x2 on Desktop, 1 Column on Mobile) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {test.stories.map((story, idx) => (
            <div
              key={idx}
              className="p-6 sm:p-8 rounded-3xl bg-gradient-to-b from-[#0c1a36] to-[#071329] border border-blue-900/60 hover:border-blue-700/80 transition-all shadow-xl flex flex-col justify-between space-y-6 relative group overflow-hidden"
            >
              <div 
                aria-hidden="true" 
                className="pointer-events-none absolute -top-12 -right-12 w-32 h-32 bg-blue-500/5 group-hover:bg-emerald-500/10 blur-2xl rounded-full transition-all" 
              />

              <div className="space-y-4 relative z-10">
                {/* Card Header: Client Tag & Milestone */}
                <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-blue-900/50">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-blue-950 border border-blue-700/60 flex items-center justify-center text-[#facc15] shrink-0">
                      <UserCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-white block">
                        {story.tag}
                      </span>
                      <span className="text-[11px] font-mono text-slate-400">
                        {story.impactArea}
                      </span>
                    </div>
                  </div>

                  <span className="text-[11px] font-mono font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800/50 px-3 py-1 rounded-full">
                    {story.milestone}
                  </span>
                </div>

                {/* Quote Content */}
                <div className="relative">
                  <Quote className="w-8 h-8 text-blue-500/20 absolute -top-2 -left-2 -z-0" />
                  <p className="text-sm sm:text-base text-slate-200 leading-relaxed font-medium relative z-10 italic">
                    &ldquo;{story.quote}&rdquo;
                  </p>
                </div>
              </div>

              {/* Card Footer: Impact of Guidance Key Takeaway */}
              <div className="p-3.5 rounded-2xl bg-[#060e20]/80 border border-blue-900/40 relative z-10">
                <div className="flex items-start gap-2 text-xs sm:text-sm text-slate-300">
                  <TrendingUp className="w-4 h-4 text-[#facc15] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-[#facc15] mr-1">
                      {isRTL ? 'رہنمائی کا اثر:' : 'Impact of Guidance:'}
                    </span>
                    <span className="text-slate-200">
                      {story.keyTakeaway}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Confidentiality & Anonymity Reassurance Banner */}
        <div className="p-4 sm:p-5 rounded-2xl bg-[#060e20] border border-blue-900/60 flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
          <div className="w-10 h-10 rounded-xl bg-blue-950/80 border border-blue-700/50 flex items-center justify-center shrink-0 text-emerald-400">
            <Lock className="w-5 h-5" />
          </div>
          <div className="flex-1 text-xs text-slate-300 leading-relaxed">
            <p>{test.privacyNotice}</p>
          </div>
          <div className="shrink-0 flex items-center gap-1.5 text-xs font-mono font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-3 py-1.5 rounded-full">
            <ShieldCheck className="w-4 h-4" />
            <span>100% Confidential</span>
          </div>
        </div>

        {/* Soft Call to Action Card */}
        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#0c1a36] via-[#0b1933] to-[#071329] border border-blue-900/80 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
          <div>
            <h3 className="text-xl sm:text-2xl font-black text-white">
              {test.ctaText}
            </h3>
            <p className="mt-1 text-xs sm:text-sm text-slate-300">
              {isRTL 
                ? 'اپنے چیلنجز پر کھل کر بات کریں اور ذاتی رہنمائی کا آغاز کریں۔'
                : 'Share where you are stuck and explore structured personal guidance today.'}
            </p>
          </div>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="shrink-0 inline-flex items-center gap-2.5 px-6 py-3.5 text-sm sm:text-base font-black text-white bg-[#25D366] hover:bg-[#20bd5a] active:scale-[0.98] rounded-xl transition-all shadow-lg shadow-emerald-950/60 border border-emerald-300/40 group whitespace-nowrap"
          >
            <MessageCircle className="w-5 h-5 fill-white shrink-0 group-hover:scale-110 transition-transform" />
            <span>{test.ctaButton}</span>
            <ArrowRight className={`w-4 h-4 shrink-0 ${isRTL ? 'rotate-180' : ''}`} />
          </a>
        </div>

      </div>
    </section>
  );
};
