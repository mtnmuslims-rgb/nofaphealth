import React, { useState } from 'react';
import { ArrowRight, AlertTriangle, RefreshCw, Zap, Moon, ShieldAlert } from 'lucide-react';

interface ProblemSectionProps {
  onOpenBooking: () => void;
}

export const ProblemSection: React.FC<ProblemSectionProps> = ({ onOpenBooking }) => {
  const [activeStep, setActiveStep] = useState<number>(0);

  const cycleSteps = [
    {
      title: '1. The Covert Trigger',
      trigger: 'Stress, Boredom, Late-Night Solitude, or Fatigue',
      problem: 'You don’t even realize you’re feeling vulnerable. Your brain automatically seeks quick dopamine to soothe distress.',
      guidanceFix: 'Guidance trains you to identify environmental triggers before they reach conscious cravings.',
      icon: Moon
    },
    {
      title: '2. The Subtle Compromise',
      trigger: 'Casual social media scrolling, "peeking", or rationalizing "just a minute"',
      problem: 'You convince yourself you’re in control. In reality, the neurochemical dopamine cascade has already fired.',
      guidanceFix: 'Environmental friction and strict zero-compromise boundaries established with your guide prevent the first peek.',
      icon: AlertTriangle
    },
    {
      title: '3. The Automatic Habit Loop',
      trigger: 'Prefrontal cortex goes offline; automatic motor memory takes over',
      problem: 'Willpower depletes. You slip into the exact same behavior you promised yourself you’d never do again.',
      guidanceFix: 'Emergency somatic protocols (urge surfing, dive reflex, cold water) physically disrupt the loop in under 90 seconds.',
      icon: Zap
    },
    {
      title: '4. Post-Relapse Shame & The "Chaser"',
      trigger: 'Intense guilt, self-loathing, feeling like all previous days were wasted',
      problem: 'Shame produces more cortisol and dopamine deficit, leading to multiple relapses in 48 hours (the Chaser Effect).',
      guidanceFix: 'Non-judgmental debrief within 24 hours removes shame, analyzes the breakdown data, and stops the spiral cold.',
      icon: RefreshCw
    },
    {
      title: '5. The False Tomorrow',
      trigger: '"Tomorrow I’ll start fresh with 100% motivation"',
      problem: 'Relying on transient emotional motivation instead of concrete systems ensures the cycle repeats in 7–14 days.',
      guidanceFix: 'Structured weekly accountability replaces fickle motivation with an objective weekly audit and continuous check-ins.',
      icon: ShieldAlert
    }
  ];

  return (
    <section id="problem" className="relative py-20 lg:py-28 bg-[#081226] border-b border-blue-950/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <span className="text-xs font-semibold tracking-wider uppercase text-emerald-400 font-mono">
            THE RELAPSE CYCLE
          </span>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight [text-wrap:balance]">
            Are You Tired of Starting Over Again and Again?
          </h2>
          <div className="w-16 h-1 bg-gradient-to-r from-blue-500 via-[#facc15] to-emerald-400 mx-auto mt-4 rounded-full" />
        </div>

        {/* Core Narrative as requested by the user prompt */}
        <div className="mt-12 max-w-3xl mx-auto space-y-6 text-slate-200 text-base sm:text-lg leading-relaxed">
          <p className="text-xl sm:text-2xl font-medium text-white leading-snug">
            Have you watched countless videos, read articles, followed motivational advice, and promised yourself that this time would be different?
          </p>
          <p>
            But after a few days or weeks, you find yourself falling back into the same habits.
          </p>
          <p className="font-semibold text-rose-300 text-lg">
            You feel frustrated, disappointed, and sometimes lose confidence in yourself.
          </p>
          <p className="text-xl font-extrabold text-white">
            You are not alone.
          </p>
          <p>
            Reading articles and watching motivational videos can provide useful information, but sometimes information alone is not enough.
          </p>
          <p>
            You may already know <strong className="text-white">WHAT</strong> you need to do. What you might be missing is <span className="text-[#facc15] font-semibold underline decoration-[#facc15]/50 underline-offset-4">consistent accountability and personal guidance</span>.
          </p>
          <p>
            Sometimes you need someone who can listen, understand your challenges, help you recognize triggers, and guide you step by step toward healthier habits.
          </p>
        </div>

        {/* Highlight statement in a beautiful design matching the logo's royal blue & gold ribbon */}
        <div className="mt-14 max-w-4xl mx-auto">
          <div className="relative overflow-hidden rounded-2xl border-2 border-amber-400/50 bg-gradient-to-br from-[#0c224d] via-[#091838] to-[#061129] p-8 sm:p-10 shadow-2xl shadow-blue-950/60 text-center">
            
            <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute -left-10 -top-10 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
            
            <span className="text-xs uppercase tracking-widest text-[#facc15] font-bold font-mono">
              KEY PRINCIPLE FOR LASTING FREEDOM
            </span>

            <p className="mt-3 text-xl sm:text-2xl md:text-3xl font-black text-white tracking-tight leading-snug [text-wrap:balance]">
              &ldquo;DON&apos;T JUST COLLECT INFORMATION. START TAKING ACTION WITH PERSONAL GUIDANCE.&rdquo;
            </p>

            <p className="mt-4 text-sm sm:text-base text-slate-300 max-w-2xl mx-auto">
              Information teaches the mind. Real accountability transforms daily behavior.
            </p>

            <div className="mt-6">
              <button
                onClick={onOpenBooking}
                className="px-7 py-3 text-sm font-extrabold text-slate-950 bg-gradient-to-r from-[#facc15] to-[#eab308] rounded-xl hover:from-amber-300 hover:to-amber-400 transition-all shadow-md cursor-pointer inline-flex items-center gap-2 border border-amber-300/40"
              >
                <span>Speak with an Experienced Guide</span>
                <ArrowRight className="w-4 h-4 text-slate-950" />
              </button>
            </div>
          </div>
        </div>

        {/* Interactive Breakdown of the Relapse Cycle & Guidance Solutions */}
        <div className="mt-20">
          <div className="text-center max-w-2xl mx-auto mb-8">
            <h3 className="text-xl sm:text-2xl font-bold text-white">
              Deconstructing the 5-Stage Habit Loop
            </h3>
            <p className="mt-2 text-sm text-slate-400">
              Select each phase to see why individual willpower collapses and how tailored guidance breaks the loop.
            </p>
          </div>

          {/* Interactive Steps Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 max-w-4xl mx-auto mb-6">
            {cycleSteps.map((step, idx) => (
              <button
                key={step.title}
                onClick={() => setActiveStep(idx)}
                className={`p-3 rounded-xl text-left text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                  activeStep === idx
                    ? 'bg-gradient-to-r from-[#facc15] to-[#eab308] text-slate-950 shadow-md font-bold'
                    : 'bg-[#0c1a36]/80 text-slate-300 hover:text-white hover:bg-[#102347] border border-blue-900/50'
                }`}
              >
                <div className="truncate">{step.title}</div>
              </button>
            ))}
          </div>

          {/* Active Step Card */}
          <div className="max-w-4xl mx-auto p-6 sm:p-8 rounded-2xl bg-[#0c1a36]/80 border border-blue-800/60 text-left shadow-xl">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-xl bg-blue-900/40 border border-blue-600/50 text-[#facc15] shrink-0 mt-1">
                {React.createElement(cycleSteps[activeStep].icon, { className: 'w-6 h-6' })}
              </div>
              <div className="space-y-4 flex-1">
                <div>
                  <span className="text-xs font-mono uppercase tracking-wider text-emerald-400 font-semibold">
                    Stage {activeStep + 1}
                  </span>
                  <h4 className="text-lg sm:text-xl font-bold text-white mt-0.5">
                    {cycleSteps[activeStep].title}: <span className="text-slate-200 font-normal">{cycleSteps[activeStep].trigger}</span>
                  </h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  <div className="p-4 rounded-xl bg-rose-950/30 border border-rose-900/50">
                    <span className="text-xs font-bold text-rose-300 uppercase tracking-wide">
                      Why Willpower Alone Fails
                    </span>
                    <p className="mt-1.5 text-xs sm:text-sm text-slate-300 leading-relaxed">
                      {cycleSteps[activeStep].problem}
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-700/50">
                    <span className="text-xs font-bold text-emerald-400 uppercase tracking-wide">
                      The NoFap Health Guidance Solution
                    </span>
                    <p className="mt-1.5 text-xs sm:text-sm text-slate-200 leading-relaxed">
                      {cycleSteps[activeStep].guidanceFix}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
