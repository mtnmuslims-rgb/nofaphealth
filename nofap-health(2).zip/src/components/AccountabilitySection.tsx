import React from 'react';
import { CheckCircle2, Shield, HeartHandshake, Eye, MessageSquare, ArrowRight } from 'lucide-react';

interface AccountabilitySectionProps {
  onOpenBooking: () => void;
}

export const AccountabilitySection: React.FC<AccountabilitySectionProps> = ({ onOpenBooking }) => {
  const accountabilityBenefits = [
    {
      title: 'Breaking the Secrecy That Feeds Compulsion',
      description: 'Compulsive habits thrive in the dark. When you keep your struggle completely secret, your mind easily rationalizes slips. Sharing your journey with a trusted, non-judgmental guide removes the heavy burden of isolation and eliminates toxic shame.',
      icon: Eye
    },
    {
      title: 'Unbiased Perspective on Your Blind Spots',
      description: 'When you are inside your own head, it is difficult to see which subtle habits (e.g., taking your phone into the bathroom, scrolling social media when tired) are triggering your urges. An experienced guide helps you diagnose and patch vulnerabilities before they become relapses.',
      icon: Shield
    },
    {
      title: 'Real-Time Accountability When Willpower Is Low',
      description: 'Knowing that someone is waiting for your check-in creates healthy social friction. In moments of intense cravings, simply sending a quick message or pausing to remember your commitment gives your rational brain the 10 minutes it needs to regain control.',
      icon: MessageSquare
    },
    {
      title: 'Steady Guidance Through the Flatline & Plateaus',
      description: 'Between weeks 2 and 5, many men experience the "flatline"—low energy, temporary emotional flatness, and fear that they have lost their drive. Having a guide who has seen hundreds of people go through this keeps you calm, steady, and patient.',
      icon: HeartHandshake
    }
  ];

  return (
    <section id="accountability" className="py-20 lg:py-28 bg-[#060e20] border-b border-blue-950/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <span className="text-xs font-semibold tracking-wider uppercase text-emerald-400 font-mono">
            THE POWER OF PARTNERSHIP
          </span>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight [text-wrap:balance]">
            Why You May Need an Accountability Partner
          </h2>
          <div className="w-16 h-1 bg-gradient-to-r from-blue-500 via-[#facc15] to-emerald-400 mx-auto mt-4 rounded-full" />
        </div>

        {/* Narrative & Visual Split */}
        <div className="mt-14 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left: Image Card */}
          <div className="lg:col-span-5 order-2 lg:order-1">
            <div className="relative rounded-2xl overflow-hidden border border-blue-900/60 bg-[#0c1a36] shadow-2xl">
              <img
                src="/src/assets/images/accountability_walking_1793958468739.jpg"
                alt="Two men walking along a calm misty trail representing mutual support and accountability"
                className="w-full h-[380px] sm:h-[420px] object-cover object-center"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#060e20] via-[#060e20]/30 to-transparent" />
              
              <div className="absolute bottom-0 inset-x-0 p-6">
                <span className="text-xs font-mono font-semibold uppercase tracking-wider text-[#facc15]">
                  Non-Judgmental Peer Mentorship
                </span>
                <p className="mt-1 text-base font-bold text-white">
                  Walking side by side with someone who understands the exact road you are traveling.
                </p>
                <div className="mt-3 flex items-center gap-2 text-xs text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Based on 7–8 years of direct mentoring experience</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Core Text & Callout */}
          <div className="lg:col-span-7 order-1 lg:order-2 space-y-6">
            <div className="space-y-4 text-slate-200 text-base sm:text-lg leading-relaxed">
              <p className="text-xl sm:text-2xl font-medium text-white leading-snug">
                Sometimes, knowing what to do is not enough.
              </p>
              <p>
                You may read articles, watch recovery videos, and feel motivated to change. Yet, when difficult moments arrive, you may find yourself returning to old habits.
              </p>
              <p>
                This is where an <strong className="text-white">accountability partner or personal guide</strong> can be helpful.
              </p>
              <p className="p-5 rounded-2xl bg-[#0c1a36]/90 border border-blue-900/60 text-slate-200 shadow-inner">
                Having someone who understands your challenges and supports your progress can help you stay focused, navigate self-doubt, and build consistency that lasts beyond temporary motivation.
              </p>
            </div>

            <div className="pt-2">
              <button
                onClick={onOpenBooking}
                className="px-7 py-3.5 text-sm sm:text-base font-extrabold text-slate-950 bg-gradient-to-r from-[#facc15] to-[#eab308] rounded-xl hover:from-amber-300 hover:to-amber-400 transition-all shadow-md inline-flex items-center gap-2 cursor-pointer border border-amber-300/40"
              >
                <span>Find Your Accountability Partner</span>
                <ArrowRight className="w-4 h-4 text-slate-950" />
              </button>
            </div>
          </div>

        </div>

        {/* 4 Pillars of Real Accountability */}
        <div className="mt-16 pt-12 border-t border-blue-900/60">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <h3 className="text-2xl font-bold text-white">
              What Real, Structured Accountability Looks Like
            </h3>
            <p className="mt-2 text-sm text-slate-300">
              Not nagging, lecturing, or guilt. Clear frameworks and dependable presence.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {accountabilityBenefits.map((benefit, bIdx) => {
              const iconColors = [
                'text-blue-400 bg-blue-950/80 border-blue-600/50',
                'text-emerald-400 bg-emerald-950/80 border-emerald-600/50',
                'text-[#facc15] bg-amber-950/80 border-amber-500/50',
                'text-cyan-400 bg-cyan-950/80 border-cyan-600/50',
              ];

              return (
                <div
                  key={benefit.title}
                  className="p-6 rounded-2xl bg-[#0c1a36]/70 border border-blue-900/50 hover:border-blue-700/80 transition-all flex items-start gap-4"
                >
                  <div className={`p-3 rounded-xl border shrink-0 mt-1 ${iconColors[bIdx % iconColors.length]}`}>
                    {React.createElement(benefit.icon, { className: 'w-6 h-6' })}
                  </div>
                  <div>
                    <h4 className="text-base sm:text-lg font-bold text-white">
                      {benefit.title}
                    </h4>
                    <p className="mt-2 text-sm text-slate-300 leading-relaxed">
                      {benefit.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

        </div>

      </div>
    </section>
  );
};
