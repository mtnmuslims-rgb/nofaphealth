import React, { useState } from 'react';
import { ARTICLES_DATA } from '../data/articles';
import { Article } from '../types';
import { ArrowUpRight, BookOpen, Clock } from 'lucide-react';

interface ArticlesSectionProps {
  onSelectArticle: (article: Article) => void;
}

export const ArticlesSection: React.FC<ArticlesSectionProps> = ({ onSelectArticle }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = [
    'All',
    'Neurobiology',
    'Practical Strategies',
    'Habit Architecture',
    'Mindset & Psychology'
  ];

  const filteredArticles = selectedCategory === 'All'
    ? ARTICLES_DATA
    : ARTICLES_DATA.filter((a) => a.category === selectedCategory);

  return (
    <section id="articles" className="py-20 lg:py-28 bg-[#081226] border-b border-blue-950/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto">
          <span className="text-xs font-semibold tracking-wider uppercase text-emerald-400 font-mono">
            EVIDENCE-BASED EDUCATION
          </span>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight [text-wrap:balance]">
            Educational Articles & Science-Backed Insights
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-200">
            Understand the neurobiology of dopamine, environment design, and practical methods to ride the craving wave.
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-blue-500 via-[#facc15] to-emerald-400 mx-auto mt-4 rounded-full" />
        </div>

        {/* Interactive Segmented Filter Controls */}
        <div className="mt-12 flex flex-wrap items-center justify-center gap-1.5 p-2 bg-[#0c1a36]/90 border border-blue-900/60 rounded-2xl max-w-2xl mx-auto shadow-inner">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-[#facc15] to-[#eab308] text-slate-950 shadow-md border border-amber-300/50'
                  : 'text-slate-300 hover:text-white hover:bg-blue-900/40'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Articles Grid */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredArticles.map((article) => (
            <article
              key={article.id}
              onClick={() => onSelectArticle(article)}
              className="group rounded-3xl bg-[#0c1a36]/70 border border-blue-900/60 hover:border-blue-600/80 transition-all duration-300 overflow-hidden flex flex-col justify-between cursor-pointer hover:-translate-y-1 shadow-xl hover:shadow-2xl hover:shadow-blue-950/60"
            >
              <div>
                {/* Image */}
                <div className="relative h-48 overflow-hidden bg-[#060e20]">
                  <img
                    src={article.image}
                    alt={article.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0c1a36] via-transparent to-transparent opacity-80" />
                </div>

                {/* Content */}
                <div className="p-6">
                  {/* Clean unboxed metadata */}
                  <div className="flex items-center gap-2 text-xs text-slate-300 font-mono mb-3">
                    <span className="text-emerald-400 font-bold">{article.category}</span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="flex items-center gap-1 text-slate-400">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>{article.readTime}</span>
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white group-hover:text-[#facc15] transition-colors leading-snug line-clamp-2">
                    {article.title}
                  </h3>

                  <p className="mt-2.5 text-xs sm:text-sm text-slate-300 line-clamp-3 leading-relaxed">
                    {article.excerpt}
                  </p>
                </div>
              </div>

              {/* Card Footer Link */}
              <div className="px-6 pb-6 pt-0 flex items-center justify-between text-xs text-slate-400 font-medium border-t border-blue-900/50 mt-4">
                <span className="text-slate-400 pt-3">{article.publishedDate}</span>
                <span className="pt-3 text-[#facc15] flex items-center gap-1 font-bold group-hover:underline">
                  <span>Read Article</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </article>
          ))}
        </div>

      </div>
    </section>
  );
};
