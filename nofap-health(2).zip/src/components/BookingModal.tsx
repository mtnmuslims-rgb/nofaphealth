import React, { useState, useEffect } from 'react';
import { GuidancePackage } from '../types';
import { X, CheckCircle2, ShieldCheck, Calendar, Clock, MessageSquare, Send } from 'lucide-react';
import { GUIDANCE_PACKAGES } from '../data/packages';

interface BookingModalProps {
  isOpen: boolean;
  selectedPackage: GuidancePackage | null;
  onClose: () => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({ isOpen, selectedPackage, onClose }) => {
  const [packageName, setPackageName] = useState<string>('Weekly Accountability Partnership');
  const [name, setName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [contactMethod, setContactMethod] = useState<string>('Telegram');
  const [contactHandle, setContactHandle] = useState<string>('');
  const [timezone, setTimezone] = useState<string>('UTC / GMT');
  const [biggestChallenge, setBiggestChallenge] = useState<string>('');
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);

  useEffect(() => {
    if (selectedPackage) {
      setPackageName(selectedPackage.title);
    }
  }, [selectedPackage]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Validate email
    if (!email || !email.includes('@')) {
      alert('Please enter a valid email address.');
      return;
    }
    setIsSubmitted(true);
  };

  const handleResetForm = () => {
    setIsSubmitted(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-xl rounded-3xl bg-[#0c1a36] border border-blue-900/80 shadow-2xl my-8 overflow-hidden">
        
        {/* Header with Logo Badge */}
        <div className="flex items-center justify-between border-b border-blue-900/60 bg-[#060e20]/90 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full p-0.5 bg-gradient-to-tr from-blue-600 via-emerald-400 to-[#facc15] shadow-md shrink-0">
              <img
                src="/assets/aistudio/Glossy_Nofap_Health_Wellness_Badge_0df9b0fb.png"
                alt="NoFap Health logo"
                className="w-full h-full object-contain rounded-full bg-white"
              />
            </div>
            <div>
              <span className="text-[11px] font-mono uppercase tracking-wider text-emerald-400 font-bold block">
                Private Consultation Request
              </span>
              <h3 className="text-base sm:text-lg font-black text-white leading-tight">
                Get Personal Guidance & Support
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-blue-900/40 transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8">
          {!isSubmitted ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-300 flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  <strong>100% Confidentiality Guarantee:</strong> You may use a pseudonym or first name. All conversations and details are strictly private.
                </span>
              </div>

              {/* Package selector */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1 font-mono">
                  Guidance Option
                </label>
                <select
                  value={packageName}
                  onChange={(e) => setPackageName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-sm text-slate-200 rounded-lg px-3 py-2.5 focus:outline-none focus:border-amber-400"
                >
                  {GUIDANCE_PACKAGES.map((pkg) => (
                    <option key={pkg.id} value={pkg.title}>
                      {pkg.title} ({pkg.duration})
                    </option>
                  ))}
                  <option value="Initial Discovery Consultation">
                    Initial Discovery & Needs Evaluation (30 Mins)
                  </option>
                </select>
              </div>

              {/* Name (or Pseudonym) & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1 font-mono">
                    Name or Pseudonym
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Alex or Initial"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-sm text-slate-200 rounded-lg px-3 py-2.5 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1 font-mono">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="your.email@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-sm text-slate-200 rounded-lg px-3 py-2.5 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Preferred Communication Channel */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1 font-mono">
                    Preferred Communication
                  </label>
                  <select
                    value={contactMethod}
                    onChange={(e) => setContactMethod(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-sm text-slate-200 rounded-lg px-3 py-2.5 focus:outline-none focus:border-amber-400"
                  >
                    <option value="Telegram">Telegram (Audio / Chat)</option>
                    <option value="Signal">Signal (Encrypted Private)</option>
                    <option value="WhatsApp">WhatsApp (Audio / Chat)</option>
                    <option value="Google Meet">Google Meet (Camera Optional)</option>
                    <option value="Zoom">Zoom Meeting</option>
                    <option value="Email Only">Email Only (Async Guidance)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1 font-mono">
                    Handle or Phone Number
                  </label>
                  <input
                    type="text"
                    placeholder="@username or number"
                    value={contactHandle}
                    onChange={(e) => setContactHandle(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-sm text-slate-200 rounded-lg px-3 py-2.5 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Timezone */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1 font-mono">
                  Your City / Timezone
                </label>
                <input
                  type="text"
                  placeholder="e.g. New York (EST), London (GMT), Dubai (GST), Sydney"
                  value={timezone}
                  onChange={(e) => setTimezone(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-sm text-slate-200 rounded-lg px-3 py-2.5 focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Biggest Challenge */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1 font-mono">
                  What is your biggest current obstacle? (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Relapsing around Day 4, late night phone use in bed, feeling isolated..."
                  value={biggestChallenge}
                  onChange={(e) => setBiggestChallenge(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-sm text-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Ethical Disclaimer acknowledgment */}
              <div className="pt-1">
                <p className="text-[11px] text-slate-400 leading-normal">
                  * By submitting, you acknowledge that NoFap Health provides non-clinical educational guidance and peer accountability, not medical or psychiatric treatment.
                </p>
              </div>

              {/* Submit CTA */}
              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 text-xs font-semibold text-slate-300 hover:text-white transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 text-xs font-extrabold text-slate-950 bg-gradient-to-r from-[#facc15] to-[#eab308] hover:from-amber-300 hover:to-amber-400 rounded-xl transition-colors cursor-pointer flex items-center gap-2 shadow-md border border-amber-300/40"
                >
                  <Send className="w-3.5 h-3.5 text-slate-950" />
                  <span>Submit Guidance Application</span>
                </button>
              </div>

            </form>
          ) : (
            /* Confirmation Screen */
            <div className="text-center py-6 space-y-4">
              <div className="inline-flex p-3 rounded-full bg-emerald-950/60 border border-emerald-500/40 text-emerald-400">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <h4 className="text-xl font-bold text-white">
                Application Received Confidentially
              </h4>

              <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                Thank you, <strong className="text-white">{name}</strong>. Your inquiry for <span className="text-amber-400 font-medium">{packageName}</span> has been securely logged.
              </p>

              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-left text-xs text-slate-300 space-y-2 max-w-md mx-auto">
                <p className="font-semibold text-white">What happens next?</p>
                <p>1. We will review your timezone ({timezone}) and schedule availability.</p>
                <p>2. You will receive a private response to <strong className="text-slate-100">{email}</strong> within 12–24 hours.</p>
                <p>3. We will propose 2 specific call times and an optional preparatory intake guide.</p>
              </div>

              <div className="pt-4">
                <button
                  onClick={handleResetForm}
                  className="px-6 py-2.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer"
                >
                  Return to Website
                </button>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
