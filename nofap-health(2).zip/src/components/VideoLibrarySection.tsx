import React, { useState } from 'react';
import { VIDEO_TALKS } from '../data/videos';
import { Play, Clock, Sparkles, CheckCircle2, Bookmark, Volume2, ArrowRight } from 'lucide-react';
import { VideoTalk } from '../types';

interface VideoLibrarySectionProps {
  onOpenBooking: () => void;
}

export const VideoLibrarySection: React.FC<VideoLibrarySectionProps> = ({ onOpenBooking }) => {
  const [activeVideo, setActiveVideo] = useState<VideoTalk>(VIDEO_TALKS[0]);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentPlaybackTime, setCurrentPlaybackTime] = useState<string>('00:00');

  const handleJumpTo = (timeStr: string) => {
    setCurrentPlaybackTime(timeStr);
    setIsPlaying(true);
  };

  return (
    <section className="py-20 lg:py-28 bg-[#060e20] border-b border-blue-950/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto">
          <span className="text-xs font-semibold tracking-wider uppercase text-emerald-400 font-mono">
            GUIDANCE AUDIO & VIDEO SESSIONS
          </span>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight [text-wrap:balance]">
            Informative Video & Audio Talks
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-200">
            Listen to targeted talks addressing the specific emotional and environmental triggers of compulsive habit loops.
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-blue-500 via-[#facc15] to-emerald-400 mx-auto mt-4 rounded-full" />
        </div>

        {/* Video Player & Playlist Layout */}
        <div className="mt-14 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Main Active Player View (8 cols) */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Player Container */}
            <div className="relative rounded-3xl overflow-hidden bg-[#0c1a36] border border-blue-900/70 shadow-2xl">
              
              {/* Cinematic Simulated Video Canvas */}
              <div className="relative w-full aspect-video bg-gradient-to-br from-[#0c1e42] via-[#081530] to-[#050c1c] flex items-center justify-center p-6 text-center">
                
                {/* Background ambient lighting */}
                <div className="absolute inset-0 bg-radial from-blue-500/15 via-transparent to-transparent opacity-60 pointer-events-none" />

                <div className="relative z-10 max-w-lg space-y-4">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#060e20]/80 border border-blue-700/60 text-[#facc15] text-xs font-mono">
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>Audio & Video Masterclass</span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-black text-white leading-snug">
                    {activeVideo.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-300">
                    Duration: {activeVideo.duration} · Category: <span className="text-emerald-400 font-semibold">{activeVideo.category}</span>
                  </p>

                  <div className="pt-2 flex items-center justify-center gap-3">
                    <button
                      onClick={() => setIsPlaying(!isPlaying)}
                      className="px-7 py-3 rounded-xl font-extrabold text-sm bg-gradient-to-r from-[#facc15] to-[#eab308] text-slate-950 hover:from-amber-300 hover:to-amber-400 transition-all flex items-center gap-2 shadow-lg shadow-blue-950/60 cursor-pointer border border-amber-300/50"
                    >
                      <Play className="w-4 h-4 fill-slate-950" />
                      <span>{isPlaying ? 'Pause Session' : 'Play Guided Session'}</span>
                    </button>
                  </div>

                  {isPlaying && (
                    <div className="text-xs text-emerald-400 font-mono animate-pulse pt-2">
                      Now playing at {currentPlaybackTime} / {activeVideo.duration}
                    </div>
                  )}
                </div>

                {/* Bottom Scrub Bar Simulation */}
                <div className="absolute bottom-0 inset-x-0 bg-slate-950/90 border-t border-slate-800 p-3 flex items-center justify-between text-xs text-slate-400 font-mono">
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400">{currentPlaybackTime}</span>
                    <span>/</span>
                    <span>{activeVideo.duration}</span>
                  </div>
                  <div className="hidden sm:block text-slate-400">
                    NoFap Health Masterclass
                  </div>
                </div>

              </div>

            </div>

            {/* Video Details & Timestamps */}
            <div className="p-6 sm:p-8 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-6">
              
              <div>
                <span className="text-xs uppercase font-mono tracking-wider text-amber-400 font-semibold">
                  Session Overview
                </span>
                <p className="mt-2 text-sm sm:text-base text-slate-200 leading-relaxed">
                  {activeVideo.description}
                </p>
              </div>

              {/* Timestamp Navigation */}
              <div>
                <h4 className="text-xs uppercase font-mono tracking-wider text-slate-400 mb-3 font-semibold">
                  Key Moments & Timestamps (Click to Jump):
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {activeVideo.keyMoments.map((moment, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleJumpTo(moment.time)}
                      className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800 hover:border-amber-400/50 text-left transition-all flex items-center gap-2.5 text-xs text-slate-300 hover:text-white cursor-pointer"
                    >
                      <span className="font-mono font-bold text-amber-400 shrink-0 bg-amber-400/10 px-1.5 py-0.5 rounded">
                        {moment.time}
                      </span>
                      <span className="truncate">{moment.topic}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Reflection Prompt */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800">
                <div className="flex items-center gap-2 text-xs font-mono font-bold text-amber-400 uppercase tracking-wide">
                  <Bookmark className="w-4 h-4" />
                  <span>Personal Reflection Prompt</span>
                </div>
                <p className="mt-2 text-xs sm:text-sm text-slate-300 italic">
                  &ldquo;{activeVideo.reflectionPrompt}&rdquo;
                </p>
              </div>

            </div>

          </div>

          {/* Video Playlist Sidebar (4 cols) */}
          <div className="lg:col-span-4 space-y-3">
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 mb-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                Guided Video Library
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                4 Core talks curated for habit restructuring.
              </p>
            </div>

            <div className="space-y-3">
              {VIDEO_TALKS.map((video) => {
                const isSelected = activeVideo.id === video.id;
                return (
                  <div
                    key={video.id}
                    onClick={() => {
                      setActiveVideo(video);
                      setCurrentPlaybackTime('00:00');
                    }}
                    className={`p-4 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-slate-900 border-amber-400 shadow-md'
                        : 'bg-slate-900/50 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs text-slate-400 font-mono mb-1.5">
                      <span className="text-amber-400 font-medium">{video.category}</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{video.duration}</span>
                      </span>
                    </div>

                    <h4 className={`text-sm font-bold leading-snug ${isSelected ? 'text-white' : 'text-slate-200'}`}>
                      {video.title}
                    </h4>

                    <p className="mt-1.5 text-xs text-slate-400 line-clamp-2 leading-relaxed">
                      {video.description}
                    </p>
                  </div>
                );
              })}
            </div>

            {/* Need direct guidance callout */}
            <div className="mt-6 p-5 rounded-xl bg-gradient-to-br from-amber-950/30 to-slate-900 border border-amber-400/30 text-center">
              <p className="text-xs text-slate-300">
                Videos provide insight, but live dialogue provides accountability.
              </p>
              <button
                onClick={onOpenBooking}
                className="mt-3 w-full py-2.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer"
              >
                Book 1-on-1 Guidance
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
