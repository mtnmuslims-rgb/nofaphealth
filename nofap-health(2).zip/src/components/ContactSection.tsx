import React from 'react';
import { 
  Language, 
  TRANSLATIONS, 
  getWhatsAppUrl, 
  OFFICIAL_PHONE, 
  FOUNDER_NAME, 
  FOUNDER_EMAIL 
} from '../data/translations';
import { 
  MessageCircle, 
  Mail, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRight, 
  User, 
  Send 
} from 'lucide-react';

interface ContactSectionProps {
  currentLang: Language;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ currentLang }) => {
  const t = TRANSLATIONS[currentLang];
  const whatsappUrl = getWhatsAppUrl(currentLang);
  const isRTL = currentLang === 'ur';

  return (
    <section id="contact" className="py-16 lg:py-24 bg-[#081226] border-b border-blue-950/80">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 text-center">
        
        {/* Badge */}
        <span className="text-xs font-semibold tracking-wider uppercase text-emerald-400 font-mono">
          {t.contact.badge}
        </span>

        {/* Heading */}
        <h2 className="mt-2 text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight [text-wrap:balance]">
          {t.contact.heading}
        </h2>

        {/* Subheading */}
        <p className="mt-4 text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
          {t.contact.subheading}
        </p>

        {/* Contact Cards Grid: WhatsApp & Direct Email */}
        <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
          
          {/* Card 1: Official WhatsApp (Primary) */}
          <div className="p-7 sm:p-8 rounded-3xl bg-gradient-to-b from-[#0c1e42] to-[#07132b] border-2 border-emerald-500/40 shadow-2xl flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="w-14 h-14 rounded-2xl bg-[#25D366] text-white flex items-center justify-center shadow-lg shadow-emerald-950/60">
                  <MessageCircle className="w-8 h-8 fill-white" />
                </div>
                <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-3 py-1 rounded-full">
                  Fastest Response
                </span>
              </div>

              <div>
                <span className="text-xs font-mono uppercase tracking-widest text-slate-400 font-semibold block">
                  Official WhatsApp
                </span>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-1 text-2xl sm:text-3xl font-black text-white font-mono hover:text-[#facc15] transition-colors block"
                >
                  {OFFICIAL_PHONE}
                </a>
                <p className="mt-1 text-xs text-slate-300">
                  {t.contact.availability}
                </p>
              </div>
            </div>

            <div>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2.5 px-6 py-4 text-base font-black text-white bg-[#25D366] hover:bg-[#20bd5a] active:scale-[0.98] rounded-xl transition-all shadow-lg shadow-emerald-950/60 border border-emerald-300/40 group"
              >
                <MessageCircle className="w-5 h-5 fill-white shrink-0 group-hover:scale-110 transition-transform" />
                <span>{t.contact.whatsappButton}</span>
                <ArrowRight className={`w-4 h-4 shrink-0 ${isRTL ? 'rotate-180' : ''}`} />
              </a>
            </div>
          </div>

          {/* Card 2: Direct Email & Guide Name */}
          <div className="p-7 sm:p-8 rounded-3xl bg-gradient-to-b from-[#0c1a36] to-[#071024] border border-blue-900/80 shadow-2xl flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="w-14 h-14 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-lg shadow-blue-950/60">
                  <Mail className="w-8 h-8 text-white" />
                </div>
                <div className="flex items-center gap-1.5 text-xs text-[#facc15] font-mono font-bold bg-amber-950/50 border border-amber-600/40 px-3 py-1 rounded-full">
                  <User className="w-3.5 h-3.5" />
                  <span>{FOUNDER_NAME}</span>
                </div>
              </div>

              <div>
                <span className="text-xs font-mono uppercase tracking-widest text-slate-400 font-semibold block">
                  {t.contact.emailLabel}
                </span>
                <a
                  href={`mailto:${FOUNDER_EMAIL}`}
                  className="mt-1 text-xl sm:text-2xl font-black text-white font-mono hover:text-[#facc15] transition-colors break-all block"
                  title="Click to send email directly"
                >
                  {FOUNDER_EMAIL}
                </a>
                <p className="mt-1 text-xs text-slate-300">
                  {currentLang === 'ur'
                    ? 'براہِ راست ای میل ارسال کریں۔ جواب جلد دیا جائے گا۔'
                    : 'Click to open your email client for direct confidential inquiries.'}
                </p>
              </div>
            </div>

            <div>
              <a
                href={`mailto:${FOUNDER_EMAIL}`}
                className="w-full inline-flex items-center justify-center gap-2.5 px-6 py-4 text-base font-bold text-white bg-blue-600 hover:bg-blue-500 active:scale-[0.98] rounded-xl transition-all shadow-lg shadow-blue-950/60 border border-blue-400/40 group"
              >
                <Send className="w-5 h-5 text-white shrink-0 group-hover:translate-x-0.5 transition-transform" />
                <span>{t.contact.emailButton} ({FOUNDER_EMAIL})</span>
              </a>
            </div>
          </div>

        </div>

        {/* Reassurance statement */}
        <div className="mt-8 p-4 rounded-2xl bg-[#0c1a36]/80 border border-blue-900/60 flex flex-wrap items-center justify-center gap-4 text-xs sm:text-sm text-slate-300">
          <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
            <ShieldCheck className="w-4 h-4 shrink-0" />
            <span>100% Private & Confidential</span>
          </span>
          <span className="text-slate-600">·</span>
          <span className="flex items-center gap-1.5 text-[#facc15] font-medium">
            <User className="w-4 h-4 shrink-0" />
            <span>Direct Guidance by {FOUNDER_NAME}</span>
          </span>
          <span className="text-slate-600">·</span>
          <span className="flex items-center gap-1.5 text-blue-300 font-medium">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{t.contact.privacyAssurance}</span>
          </span>
        </div>

        {/* Core Message Highlight */}
        <div className="mt-8">
          <p className="text-xs sm:text-sm font-mono font-bold uppercase tracking-wider text-[#facc15]">
            &ldquo;{t.contact.coreMessage}&rdquo;
          </p>
        </div>

      </div>
    </section>
  );
};
