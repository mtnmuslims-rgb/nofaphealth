import React, { useEffect } from 'react';
import { Article } from '../types';
import { X, Clock, Calendar, CheckCircle2, Bookmark, Share2 } from 'lucide-react';

interface ArticleModalProps {
  article: Article | null;
  onClose: () => void;
  onOpenBooking: () => void;
}

export const ArticleModal: React.FC<ArticleModalProps> = ({ article, onClose, onOpenBooking }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (article) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [article, onClose]);

  if (!article) return null;

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      alert('Article link copied to clipboard.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-3xl rounded-3xl bg-[#0c1a36] border border-blue-900/80 shadow-2xl my-8 overflow-hidden">
        
        {/* Sticky Modal Header */}
        <div className="sticky top-0 z-20 flex items-center justify-between border-b border-blue-900/60 bg-[#060e20]/95 px-6 py-4 backdrop-blur-sm">
          {/* Logo badge and clean unboxed metadata */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full p-0.5 bg-gradient-to-tr from-blue-600 via-emerald-400 to-[#facc15] shadow-sm shrink-0">
              <img
                src="/assets/aistudio/Glossy_Nofap_Health_Wellness_Badge_0df9b0fb.png"
                alt="NoFap Health logo"
                className="w-full h-full object-contain rounded-full bg-white"
              />
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-300 font-mono">
              <span className="text-emerald-400 font-bold">{article.category}</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>{article.readTime}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-blue-900/40 transition-colors cursor-pointer"
              title="Share article"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-blue-900/40 transition-colors cursor-pointer"
              title="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-10 space-y-8 max-h-[80vh] overflow-y-auto">
          
          {/* Article Title & Lead */}
          <div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white leading-tight">
              {article.title}
            </h1>
            <p className="mt-3 text-base sm:text-lg text-slate-300 leading-relaxed italic">
              {article.excerpt}
            </p>
            <div className="mt-4 flex items-center gap-3 text-xs text-slate-500">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>{article.publishedDate}</span>
              </span>
              <span aria-hidden="true">·</span>
              <span>NoFap Health Editorial Guidance</span>
            </div>
          </div>

          {/* Featured Image */}
          <div className="rounded-xl overflow-hidden border border-slate-800 max-h-[320px]">
            <img
              src={article.image}
              alt={article.title}
              className="w-full h-full object-cover"
              loading="lazy"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Key Takeaways Box */}
          <div className="p-5 sm:p-6 rounded-xl bg-slate-950/80 border border-amber-400/30 space-y-3">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-400 font-bold">
              <Bookmark className="w-4 h-4" />
              <span>Core Takeaways</span>
            </div>
            <ul className="space-y-2">
              {article.keyTakeaways.map((takeaway, tIdx) => (
                <li key={tIdx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>{takeaway}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Full Prose Content */}
          <div className="space-y-5 text-sm sm:text-base text-slate-300 leading-relaxed font-normal">
            {article.content.map((paragraph, pIdx) => (
              <p key={pIdx}>
                {paragraph}
              </p>
            ))}
          </div>

          {/* Practical Action Steps */}
          <div className="p-6 rounded-xl bg-slate-950/90 border border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-white uppercase tracking-wider font-mono">
              Immediate Action Steps To Implement Today:
            </h3>
            <div className="space-y-2.5">
              {article.actionSteps.map((step, sIdx) => (
                <div key={sIdx} className="flex items-start gap-3 p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs sm:text-sm text-slate-200">
                  <span className="font-mono text-amber-400 font-bold shrink-0">{sIdx + 1}.</span>
                  <span>{step}</span>
                </div>
              ))}
            </div>
          </div>

          {/* End-of-Article Guidance CTA */}
          <div className="p-6 rounded-xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 border border-amber-400/40 text-center sm:text-left sm:flex items-center justify-between gap-6">
            <div>
              <h4 className="text-base font-bold text-white">Need support putting this into practice?</h4>
              <p className="mt-1 text-xs text-slate-300">
                Work directly with an experienced personal guide for weekly accountability.
              </p>
            </div>
            <button
              onClick={() => {
                onClose();
                onOpenBooking();
              }}
              className="mt-4 sm:mt-0 px-5 py-2.5 text-xs font-bold text-slate-950 bg-amber-400 rounded-lg hover:bg-amber-300 transition-all shrink-0 cursor-pointer"
            >
              Get Personal Guidance
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
