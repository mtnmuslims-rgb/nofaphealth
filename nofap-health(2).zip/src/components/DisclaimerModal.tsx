import React, { useEffect } from 'react';
import { X, ShieldAlert, Check } from 'lucide-react';

interface DisclaimerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DisclaimerModal: React.FC<DisclaimerModalProps> = ({ isOpen, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-3xl bg-[#0c1a36] border border-blue-900/80 shadow-2xl my-8 overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-blue-900/60 bg-[#060e20]/90 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full p-0.5 bg-gradient-to-tr from-blue-600 via-emerald-400 to-[#facc15] shadow-sm shrink-0">
              <img
                src="/assets/aistudio/Glossy_Nofap_Health_Wellness_Badge_0df9b0fb.png"
                alt="NoFap Health logo"
                className="w-full h-full object-contain rounded-full bg-white"
              />
            </div>
            <div className="flex items-center gap-2 text-rose-400 font-mono text-xs font-bold uppercase tracking-wider">
              <ShieldAlert className="w-4 h-4" />
              <span>Non-Clinical Peer Mentorship Disclosure</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-blue-900/40 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 space-y-5 text-slate-300 text-xs sm:text-sm leading-relaxed max-h-[75vh] overflow-y-auto">
          
          <h2 className="text-xl font-bold text-white leading-snug">
            Medical, Psychological & Legal Notice
          </h2>

          <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-900/50 text-rose-200">
            <strong>CRITICAL STATEMENT:</strong> The website owner, creators, and mentors representing NoFap Health are NOT licensed medical doctors, psychiatrists, clinical psychologists, or registered mental health therapists.
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-white uppercase font-mono text-xs tracking-wider">
              1. Scope of Service:
            </h4>
            <p>
              The services provided by NoFap Health comprise <strong>non-clinical personal guidance, lifestyle habit coaching, behavioral environment design, and peer accountability</strong>. This guidance is built upon approximately 7 to 8 years of personal practical experience helping individuals overcome compulsive pornography and masturbation patterns.
            </p>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-white uppercase font-mono text-xs tracking-wider">
              2. No Medical Claims or Guaranteed Recovery:
            </h4>
            <p>
              We do not provide medical diagnosis, prescribe pharmaceutical medications, or guarantee clinical recovery outcomes. Every human nervous system and life context is unique; individual results depend on personal dedication, environment engineering, and emotional circumstances.
            </p>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-white uppercase font-mono text-xs tracking-wider">
              3. When to Seek Licensed Professional Care:
            </h4>
            <p>
              If you are experiencing severe depression, anxiety disorders, suicidal ideation, untreated trauma, or psychiatric conditions, you must seek immediate care from a licensed physician, clinical psychologist, or mental health emergency service in your jurisdiction.
            </p>
            <p className="text-slate-400">
              International Crisis Resources:
              <br />
              • US/Canada: Dial 988 (Suicide & Crisis Lifeline)
              <br />
              • UK: Dial 111 (NHS) or 116 123 (Samaritans)
              <br />
              • International: Visit <a href="https://findahelpline.com" target="_blank" rel="noreferrer" className="text-amber-400 underline">findahelpline.com</a>
            </p>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-white uppercase font-mono text-xs tracking-wider">
              4. Educational Purpose:
            </h4>
            <p>
              All written articles, video talks, interactive tools, timers, and assessment quizzes on this website are designed solely for general educational and motivational guidance.
            </p>
          </div>

          <div className="pt-4 border-t border-slate-800 flex justify-end">
            <button
              onClick={onClose}
              className="px-6 py-2.5 rounded-lg text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>I Understand & Acknowledge</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
