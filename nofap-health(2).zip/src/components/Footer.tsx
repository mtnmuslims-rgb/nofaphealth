import React from 'react';
import { 
  Language, 
  TRANSLATIONS, 
  getWhatsAppUrl, 
  OFFICIAL_PHONE, 
  FOUNDER_NAME, 
  FOUNDER_EMAIL 
} from '../data/translations';
import { MessageCircle, Mail, User, ShieldAlert } from 'lucide-react';

interface FooterProps {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
}

export const Footer: React.FC<FooterProps> = ({ currentLang, onLanguageChange }) => {
  const t = TRANSLATIONS[currentLang];
  const whatsappUrl = getWhatsAppUrl(currentLang);

  return (
    <footer className="bg-[#040a17] border-t border-blue-950 text-slate-300 py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Top: Brand Lockup & Contact Links */}
        <div className="flex flex-col lg:flex-row items-center justify-between gap-6 pb-8 border-b border-blue-950/80 text-center lg:text-left">
          
          {/* Logo & Brand */}
          <div className="flex flex-col sm:flex-row items-center gap-3.5">
            <div className="w-12 h-12 rounded-full p-0.5 bg-gradient-to-tr from-blue-600 via-emerald-400 to-[#facc15] shadow-md shrink-0">
              <img
                src="/assets/aistudio/Glossy_Nofap_Health_Wellness_Badge_0df9b0fb.png"
                alt="NoFap Health Badge"
                className="w-full h-full object-contain rounded-full bg-white"
                loading="lazy"
              />
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-black text-white">
                <span>NOFAP</span> <span className="text-[#facc15]">HEALTH</span>
              </div>
              <p className="text-xs text-slate-300 font-medium mt-0.5">
                {t.footer.tagline}
              </p>
            </div>
          </div>

          {/* Contact Details: Guide Name, Clickable Email, and WhatsApp */}
          <div className="flex flex-wrap items-center justify-center lg:justify-end gap-6 text-sm">
            
            {/* Guide Name */}
            <div className="flex items-center gap-2 bg-[#0c1a36] px-3.5 py-2 rounded-xl border border-blue-900/60">
              <User className="w-4 h-4 text-[#facc15] shrink-0" />
              <div className="text-left">
                <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-semibold">
                  {t.footer.founderLabel}
                </span>
                <span className="text-xs font-bold text-white">
                  {FOUNDER_NAME}
                </span>
              </div>
            </div>

            {/* Clickable Email mailto: */}
            <div className="flex items-center gap-2 bg-[#0c1a36] px-3.5 py-2 rounded-xl border border-blue-900/60">
              <Mail className="w-4 h-4 text-blue-400 shrink-0" />
              <div className="text-left">
                <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-semibold">
                  {t.footer.emailLabel}
                </span>
                <a
                  href={`mailto:${FOUNDER_EMAIL}`}
                  className="text-xs font-bold text-white hover:text-[#facc15] transition-colors font-mono"
                  title="Click to email Waseem Abbas"
                >
                  {FOUNDER_EMAIL}
                </a>
              </div>
            </div>

            {/* WhatsApp */}
            <div className="flex items-center gap-3">
              <div className="text-left sm:text-right hidden sm:block">
                <span className="text-[10px] uppercase font-mono tracking-wider text-emerald-400 block font-bold">
                  {t.footer.contactLabel}
                </span>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm font-black text-white hover:text-[#facc15] transition-colors font-mono"
                >
                  {OFFICIAL_PHONE}
                </a>
              </div>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#25D366] hover:bg-[#20bd5a] transition-all shadow-md shrink-0"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>{t.nav.whatsappButton}</span>
              </a>
            </div>

          </div>

        </div>

        {/* Middle: Short Required Disclaimer */}
        <div className="p-4 rounded-2xl bg-[#060e20] border border-blue-900/50 flex items-start gap-3">
          <ShieldAlert className="w-5 h-5 text-[#facc15] shrink-0 mt-0.5" />
          <p className="text-xs text-slate-300 leading-relaxed">
            <strong className="text-white">Disclaimer:</strong> {t.footer.disclaimer}
          </p>
        </div>

        {/* Bottom: Copyright & Language Selector Mirror */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400 pt-2">
          <p>
            &copy; {new Date().getFullYear()} {t.footer.copyright} {t.footer.rights}
          </p>

          <div className="flex items-center gap-2">
            <span className="text-slate-400">Language:</span>
            <button
              onClick={() => onLanguageChange('en')}
              className={`px-2 py-0.5 rounded text-xs font-semibold cursor-pointer ${
                currentLang === 'en' ? 'text-[#facc15] font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              English
            </button>
            <span className="text-slate-600">·</span>
            <button
              onClick={() => onLanguageChange('ur')}
              className={`px-2 py-0.5 rounded text-xs font-semibold font-serif cursor-pointer ${
                currentLang === 'ur' ? 'text-[#facc15] font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              اردو
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
