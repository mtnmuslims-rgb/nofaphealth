import React from 'react';
import { Language, TRANSLATIONS, getWhatsAppUrl } from '../data/translations';
import { 
  BookOpen, 
  AlertCircle, 
  Users, 
  Target, 
  ShieldCheck, 
  Lock, 
  MessageCircle, 
  CheckCircle2, 
  ArrowRight,
  HeartHandshake,
  Compass,
  Sparkles
} from 'lucide-react';

interface EducationSectionProps {
  currentLang: Language;
}

export const EducationSection: React.FC<EducationSectionProps> = ({ currentLang }) => {
  const t = TRANSLATIONS[currentLang];
  const edu = t.education;
  const whatsappUrl = getWhatsAppUrl(currentLang);
  const isRTL = currentLang === 'ur';

  return (
    <section id="education" className="py-16 lg:py-24 bg-[#060e20] border-b border-blue-950/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* =========================================================================
            PART 1: Understanding the Effects of Pornography and Excessive Masturbation
           ========================================================================= */}
        <div>
          <div className="text-center max-w-3xl mx-auto">
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-wider uppercase text-emerald-400 font-mono bg-emerald-950/40 border border-emerald-800/40 px-3 py-1 rounded-full">
              <BookOpen className="w-3.5 h-3.5 text-[#facc15]" />
              {edu.badge}
            </span>
            <h2 className="mt-3 text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight [text-wrap:balance]">
              {edu.title}
            </h2>
            <div className="w-20 h-1 bg-gradient-to-r from-blue-500 via-[#facc15] to-emerald-400 mx-auto mt-4 rounded-full" />
            
            <p className="mt-5 text-base sm:text-lg text-slate-200 leading-relaxed font-medium">
              {edu.intro}
            </p>
          </div>

          {/* 6 Effects Grid */}
          <div className="mt-10">
            <div className="flex items-center gap-2 mb-4 text-xs sm:text-sm font-mono font-bold uppercase tracking-wider text-amber-300">
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{edu.effectsTitle}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {edu.effects.map((effect, idx) => (
                <div
                  key={idx}
                  className="p-5 rounded-2xl bg-[#0c1a36]/90 border border-blue-900/60 hover:border-blue-700/80 transition-all flex items-start gap-3.5 shadow-lg group"
                >
                  <div className="w-7 h-7 rounded-xl bg-blue-950/90 border border-blue-600/40 flex items-center justify-center shrink-0 mt-0.5 text-[#facc15] font-mono text-xs font-bold group-hover:scale-105 transition-transform">
                    {idx + 1}
                  </div>
                  <p className="text-sm sm:text-base text-slate-200 leading-snug font-medium">
                    {effect}
                  </p>
                </div>
              ))}
            </div>

            {/* Context Note: Experiences vary individually */}
            <div className="mt-5 p-4 rounded-2xl bg-[#09152e] border border-blue-900/40 text-xs sm:text-sm text-slate-300 flex items-start gap-3">
              <Compass className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <p className="leading-relaxed">
                {edu.experiencesVaryNote}
              </p>
            </div>
          </div>
        </div>

        {/* =========================================================================
            PART 2: Why Watching Videos and Reading Articles May Not Be Enough
           ========================================================================= */}
        <div className="pt-8 border-t border-blue-950/80">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            <div className="lg:col-span-6 space-y-4">
              <span className="text-xs font-semibold tracking-wider uppercase text-[#facc15] font-mono">
                {edu.whyVideosBadge}
              </span>
              <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight leading-tight">
                {edu.whyVideosTitle}
              </h3>

              <p className="text-base sm:text-lg text-slate-200 leading-relaxed">
                {edu.whyVideosP1}
              </p>

              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#0c1a36] to-[#0e2246] border-l-4 border-l-emerald-400 border-y border-r border-blue-900/60">
                <p className="text-sm sm:text-base text-slate-100 font-medium leading-relaxed">
                  {edu.whyVideosP2}
                </p>
              </div>
            </div>

            {/* Right: An Accountability Partner Can Help You (5 points) */}
            <div className="lg:col-span-6">
              <div className="p-6 sm:p-8 rounded-3xl bg-[#08152e] border border-blue-900/80 shadow-2xl relative overflow-hidden">
                <div 
                  aria-hidden="true" 
                  className="pointer-events-none absolute -top-16 -right-16 w-48 h-48 bg-emerald-500/10 blur-2xl rounded-full" 
                />

                <div className="flex items-center gap-2.5 text-base sm:text-lg font-bold text-white mb-5">
                  <Users className="w-5 h-5 text-emerald-400 shrink-0" />
                  <h4>{edu.partnerTitle}</h4>
                </div>

                <ul className="space-y-3.5">
                  {edu.partnerBenefits.map((benefit, bIdx) => (
                    <li key={bIdx} className="flex items-start gap-3 text-sm sm:text-base text-slate-200">
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                      <span className="leading-snug">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

          </div>
        </div>

        {/* =========================================================================
            PART 3: A Personal Message (You Don't Have to Do It Alone)
           ========================================================================= */}
        <div className="p-6 sm:p-10 rounded-3xl bg-gradient-to-br from-[#0c1e42] via-[#091733] to-[#061026] border-2 border-emerald-500/40 shadow-2xl relative overflow-hidden">
          <div 
            aria-hidden="true" 
            className="pointer-events-none absolute top-0 right-0 w-80 h-80 bg-blue-600/10 blur-3xl rounded-full" 
          />

          <div className="relative z-10 max-w-4xl mx-auto text-center space-y-5">
            <span className="inline-flex items-center gap-1.5 text-xs font-mono font-bold uppercase tracking-wider text-[#facc15] bg-[#0c1a36] px-3.5 py-1.5 rounded-full border border-blue-800/80">
              <Sparkles className="w-3.5 h-3.5 text-[#facc15]" />
              {edu.personalMsgBadge}
            </span>

            <h3 className="text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight">
              {edu.personalMsgTitle}
            </h3>

            <div className="space-y-3 text-slate-200 text-base sm:text-lg leading-relaxed max-w-3xl mx-auto">
              <p>
                {edu.personalMsgP1}
              </p>
              <p>
                {edu.personalMsgP2}
              </p>
            </div>

            {/* Highlight Banner */}
            <div className="pt-2">
              <p className="text-base sm:text-lg md:text-xl font-black text-[#facc15] font-mono tracking-tight">
                &ldquo;{edu.personalMsgHighlight}&rdquo;
              </p>
            </div>

            {/* Action CTA: GET PERSONAL GUIDANCE */}
            <div className="pt-3">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-3 px-8 py-4 text-base sm:text-lg font-black text-white bg-[#25D366] hover:bg-[#20bd5a] active:scale-[0.98] rounded-2xl transition-all shadow-xl shadow-emerald-950/60 border-2 border-emerald-400/40 group"
              >
                <MessageCircle className="w-6 h-6 fill-white shrink-0 group-hover:scale-110 transition-transform" />
                <span>{edu.personalMsgCta}</span>
                <ArrowRight className={`w-5 h-5 shrink-0 ${isRTL ? 'rotate-180' : ''}`} />
              </a>
            </div>
          </div>
        </div>

        {/* =========================================================================
            PART 4: Your Privacy Matters (Your Privacy Is Our Priority)
           ========================================================================= */}
        <div className="p-6 sm:p-8 rounded-3xl bg-[#08142a] border border-blue-900/60 shadow-xl">
          <div className="flex flex-col md:flex-row items-center gap-6">
            
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-emerald-500 text-white flex items-center justify-center shrink-0 shadow-lg shadow-blue-950/60">
              <Lock className="w-8 h-8 text-white" />
            </div>

            <div className="space-y-2.5 text-center md:text-left flex-1">
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-2">
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-400">
                  {edu.privacyBadge}
                </span>
              </div>
              <h4 className="text-xl sm:text-2xl font-black text-white">
                {edu.privacyTitle}
              </h4>
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                {edu.privacyP1}
              </p>
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                {edu.privacyP2}
              </p>
              
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-blue-900/50">
                <p className="text-sm font-black text-[#facc15] font-mono">
                  {edu.privacyHighlight}
                </p>
                <span className="text-[11px] text-slate-400 font-medium">
                  {edu.privacyPracticeNote}
                </span>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
