import React from 'react';
import { ShieldCheck, HeartHandshake, Compass, CheckCircle2, ArrowRight } from 'lucide-react';

interface FounderSectionProps {
  onOpenBooking: () => void;
  onOpenDisclaimer: () => void;
}

export const FounderSection: React.FC<FounderSectionProps> = ({ onOpenBooking, onOpenDisclaimer }) => {
  return (
    <section className="py-20 lg:py-28 bg-[#081226] border-b border-blue-950/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Visual Asset */}
          <div className="lg:col-span-5">
            <div className="relative rounded-3xl overflow-hidden border border-blue-900/60 bg-[#0c1a36] shadow-2xl">
              <img
                src="/src/assets/images/mentor_guidance_room_1793958481467.jpg"
                alt="Personal guidance consultation room in warm, calm, thoughtful atmosphere"
                className="w-full h-[400px] sm:h-[460px] object-cover"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#060e20] via-[#060e20]/20 to-transparent" />
              
              <div className="absolute bottom-0 inset-x-0 p-6">
                <span className="text-xs font-mono font-semibold uppercase tracking-wider text-[#facc15]">
                  Real Guidance. Personal Support. A Better You.
                </span>
                <p className="mt-1 text-sm font-bold text-white">
                  A safe, private sanctuary to speak openly without shame or pretense.
                </p>
                <div className="mt-2 flex items-center gap-2 text-xs text-slate-300">
                  <span className="text-emerald-400 font-semibold">Non-Clinical Mentorship</span>
                  <span>·</span>
                  <span>7–8 Years Direct Experience</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Narrative & Mission */}
          <div className="lg:col-span-7 space-y-6">
            
            <div>
              <span className="text-xs font-semibold tracking-wider uppercase text-emerald-400 font-mono">
                ABOUT NOFAP HEALTH & YOUR GUIDE
              </span>
              <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold text-white tracking-tight [text-wrap:balance]">
                7–8 Years of Walking Alongside People in the Trenches
              </h2>
            </div>

            <div className="space-y-4 text-slate-300 text-sm sm:text-base leading-relaxed">
              <p>
                NoFap Health was born from a simple, urgent reality: <strong className="text-white">millions of good people are fighting compulsive digital habits in total isolation</strong>, weighed down by shame and false promises of overnight cures.
              </p>
              <p>
                Over the past <strong>7 to 8 years</strong>, I have dedicated myself to personally guiding, mentoring, and holding accountable individuals from all walks of life—university students, busy corporate executives, creative artists, and fathers.
              </p>
              <p>
                What I have learned through hundreds of real human conversations is that you cannot hate yourself into self-discipline. Real change happens when you combine <em>neurobiological understanding</em>, <em>physical environmental friction</em>, and <em>steady human accountability</em>.
              </p>
            </div>

            {/* Core Values Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-2xl bg-[#0c1a36]/80 border border-blue-900/60">
                <div className="flex items-center gap-2 font-bold text-white text-sm">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Zero Judgment, 100% Respect</span>
                </div>
                <p className="mt-1.5 text-xs text-slate-300 leading-relaxed">
                  Whatever your history, you will be met with calm, grounded empathy and constructive solutions.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#0c1a36]/80 border border-blue-900/60">
                <div className="flex items-center gap-2 font-bold text-white text-sm">
                  <HeartHandshake className="w-4 h-4 text-[#facc15]" />
                  <span>Real World Lifestyle Focus</span>
                </div>
                <p className="mt-1.5 text-xs text-slate-300 leading-relaxed">
                  We don’t just count days; we rebuild sleep, strength training, focus routines, and social presence.
                </p>
              </div>
            </div>

            {/* Clear Non-Clinical Notice */}
            <div className="p-4 rounded-2xl bg-[#060e20]/90 border border-blue-900/50 text-xs text-slate-300 leading-relaxed">
              <p>
                <strong className="text-white">Ethical Transparency:</strong> I am not a medical doctor, psychiatrist, or licensed clinical therapist. This service is non-clinical personal guidance and accountability coaching based on extensive peer experience. We do not diagnose disorders or promise miraculous clinical recovery.
              </p>
              <button
                onClick={onOpenDisclaimer}
                className="mt-2 text-[#facc15] hover:underline font-semibold cursor-pointer"
              >
                Read Full Medical & Legal Disclaimer &rarr;
              </button>
            </div>

            <div className="pt-2">
              <button
                onClick={onOpenBooking}
                className="px-7 py-3.5 text-sm sm:text-base font-extrabold text-slate-950 bg-gradient-to-r from-[#facc15] to-[#eab308] rounded-xl hover:from-amber-300 hover:to-amber-400 transition-all shadow-md inline-flex items-center gap-2 cursor-pointer border border-amber-300/40"
              >
                <span>Schedule a 1-on-1 Consultation</span>
                <ArrowRight className="w-4 h-4 text-slate-950" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
