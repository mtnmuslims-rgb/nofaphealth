import React, { useState } from 'react';
import { AssessmentQuestion } from '../types';
import { CheckCircle2, RotateCcw, ArrowRight, ShieldCheck, Sparkles } from 'lucide-react';

interface SelfAssessmentQuizProps {
  onOpenBooking: () => void;
}

const QUESTIONS: AssessmentQuestion[] = [
  {
    id: 1,
    question: 'When do you typically experience your strongest cravings or urges?',
    options: [
      { text: 'Late at night in bed when alone with my smartphone or laptop', score: 3, triggerType: 'Nighttime Environment' },
      { text: 'After a stressful workday or intense cognitive pressure', score: 2, triggerType: 'Stress Relief' },
      { text: 'During long unstructured weekends or bored afternoons', score: 2, triggerType: 'Boredom & Solitude' },
      { text: 'Triggered randomly while scrolling general social media feeds', score: 3, triggerType: 'Digital Peeking' }
    ]
  },
  {
    id: 2,
    question: 'How many times have you resolved to quit, only to relapse within 3 to 14 days?',
    options: [
      { text: 'Countless times—I am stuck in a continuous multi-week loop', score: 4 },
      { text: 'A few times every few months', score: 2 },
      { text: 'Recently realized this is a serious pattern I need to fix', score: 3 },
      { text: 'I can make it 30 days, but always crash when stress hits', score: 3 }
    ]
  },
  {
    id: 3,
    question: 'Have you ever had a real, dedicated human accountability partner or personal guide?',
    options: [
      { text: 'Never—I have kept this 100% secret and try to fight it entirely alone', score: 4 },
      { text: 'I tried talking to a friend once, but there was no real structure or follow-up', score: 3 },
      { text: 'I tried online group forums, but found them chaotic or full of relapse talk', score: 3 },
      { text: 'I had an accountability partner in the past, and it was the only time I made progress', score: 2 }
    ]
  },
  {
    id: 4,
    question: 'How does compulsive habit use currently affect your daily life and mindset?',
    options: [
      { text: 'Low energy, brain fog, guilt, and lost motivation for my goals', score: 3 },
      { text: 'Difficulty connecting with real people or partners, feeling distant', score: 4 },
      { text: 'Wasting 1–3 hours daily that should be spent on career, fitness, or sleep', score: 3 },
      { text: 'All of the above—it feels like a dark cloud over my potential', score: 4 }
    ]
  },
  {
    id: 5,
    question: 'What is your current strategy when an acute craving wave hits?',
    options: [
      { text: 'I just try to resist with sheer mental willpower (and usually fail within 30 mins)', score: 4 },
      { text: 'I try to distract myself with another screen or video game', score: 2 },
      { text: 'I bargain with myself ("just 2 minutes to take the edge off")', score: 4 },
      { text: 'I do not have a defined emergency somatic protocol in place', score: 3 }
    ]
  }
];

export const SelfAssessmentQuiz: React.FC<SelfAssessmentQuizProps> = ({ onOpenBooking }) => {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<{ [qId: number]: number }>({});
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  const handleSelectOption = (qId: number, optionScore: number) => {
    setSelectedAnswers((prev) => ({ ...prev, [qId]: optionScore }));
  };

  const handleNext = () => {
    if (currentIdx < QUESTIONS.length - 1) {
      setCurrentIdx((prev) => prev + 1);
    } else {
      setIsCompleted(true);
    }
  };

  const handleReset = () => {
    setCurrentIdx(0);
    setSelectedAnswers({});
    setIsCompleted(false);
  };

  // Calculate total score
  const totalScore = Object.values(selectedAnswers).reduce((a, b) => a + b, 0);

  return (
    <section className="py-20 lg:py-28 bg-[#060e20] border-b border-blue-950/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto">
          <span className="text-xs font-semibold tracking-wider uppercase text-emerald-400 font-mono">
            FREE SELF-DIAGNOSTIC
          </span>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight [text-wrap:balance]">
            Habit Severity & Vulnerability Assessment
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-200">
            Answer 5 confidential questions to evaluate your relapse risk factors and identify what kind of structure you need to break through.
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-blue-500 via-[#facc15] to-emerald-400 mx-auto mt-4 rounded-full" />
        </div>

        {/* Quiz Box */}
        <div className="mt-12 max-w-2xl mx-auto rounded-3xl border border-blue-900/60 bg-[#0c1a36]/90 p-6 sm:p-10 shadow-2xl">
          
          {!isCompleted ? (
            <div>
              {/* Progress bar */}
              <div className="flex items-center justify-between text-xs text-slate-400 mb-2 font-mono">
                <span>Question {currentIdx + 1} of {QUESTIONS.length}</span>
                <span>{Math.round(((currentIdx + 1) / QUESTIONS.length) * 100)}% Complete</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full mb-8 overflow-hidden">
                <div
                  className="h-full bg-amber-400 transition-all duration-300 rounded-full"
                  style={{ width: `${((currentIdx + 1) / QUESTIONS.length) * 100}%` }}
                />
              </div>

              {/* Question */}
              <h3 className="text-lg sm:text-xl font-bold text-white mb-6 leading-snug">
                {QUESTIONS[currentIdx].question}
              </h3>

              {/* Options */}
              <div className="space-y-3">
                {QUESTIONS[currentIdx].options.map((option, optIdx) => {
                  const isSelected = selectedAnswers[QUESTIONS[currentIdx].id] === option.score;
                  return (
                    <button
                      key={optIdx}
                      type="button"
                      onClick={() => handleSelectOption(QUESTIONS[currentIdx].id, option.score)}
                      className={`w-full p-4 rounded-xl text-left text-xs sm:text-sm font-medium transition-all flex items-start gap-3 cursor-pointer ${
                        isSelected
                          ? 'bg-amber-400/15 border-2 border-amber-400 text-white'
                          : 'bg-slate-950/60 border border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-950'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 ${
                        isSelected ? 'border-amber-400 bg-amber-400 text-slate-950' : 'border-slate-700'
                      }`}>
                        {isSelected && <CheckCircle2 className="w-3.5 h-3.5" />}
                      </div>
                      <span className="flex-1">{option.text}</span>
                    </button>
                  );
                })}
              </div>

              {/* Next Button */}
              <div className="mt-8 flex items-center justify-between">
                <button
                  onClick={handleReset}
                  className="text-xs text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
                >
                  Restart
                </button>

                <button
                  onClick={handleNext}
                  disabled={selectedAnswers[QUESTIONS[currentIdx].id] === undefined}
                  className={`px-6 py-2.5 rounded-lg text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer ${
                    selectedAnswers[QUESTIONS[currentIdx].id] !== undefined
                      ? 'bg-amber-400 text-slate-950 hover:bg-amber-300 shadow-md'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  <span>{currentIdx === QUESTIONS.length - 1 ? 'Calculate Diagnosis' : 'Next Question'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : (
            /* Results Screen */
            <div className="space-y-6 text-center">
              <div className="inline-flex p-3 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-400">
                <Sparkles className="w-8 h-8" />
              </div>

              <div>
                <span className="text-xs font-mono uppercase tracking-widest text-slate-400">
                  Assessment Complete
                </span>
                <h3 className="mt-1 text-2xl font-extrabold text-white">
                  Diagnosis: High Need for External Accountability
                </h3>
                <p className="mt-2 text-sm text-slate-300 max-w-lg mx-auto">
                  Your responses indicate that <strong className="text-white">willpower alone has been exhausted</strong>. You have high environmental vulnerability (especially late evening hours or stress) and carry the burden of isolation.
                </p>
              </div>

              {/* Action Blueprint Recommendations */}
              <div className="p-5 rounded-xl bg-slate-950/80 border border-slate-800 text-left space-y-3">
                <span className="text-xs font-mono uppercase tracking-wider text-amber-400 font-semibold block">
                  Top 3 Recommended Actions for You:
                </span>
                
                <div className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-300">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span><strong>Physical Screen Embargo:</strong> Charge all devices outside your bedroom by 9:30 PM. Buy a simple physical alarm.</span>
                </div>

                <div className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-300">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span><strong>Somatic Urge Pacing:</strong> When an urge strikes, use our 4-7-8 breathing tool instead of sitting frozen in anxiety.</span>
                </div>

                <div className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-300">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span><strong>One-on-One Guidance:</strong> Work with an experienced partner who can audit your weekly schedule and hold you accountable.</span>
                </div>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  onClick={onOpenBooking}
                  className="w-full sm:w-auto px-6 py-3 rounded-lg text-sm font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>Book Free Consultation Review</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={handleReset}
                  className="w-full sm:w-auto px-4 py-3 rounded-lg text-xs font-semibold text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retake Quiz</span>
                </button>
              </div>
            </div>
          )}

        </div>

      </div>
    </section>
  );
};
