import React from 'react';
import { Language, TRANSLATIONS, getWhatsAppUrl, OFFICIAL_PHONE } from '../data/translations';
import { ShieldCheck, HeartHandshake, Users, Award, MessageCircle, Sparkles } from 'lucide-react';
import consultationRoomImage from '../assets/images/mentor_guidance_room_1793958481467.jpg';

interface AboutSectionProps {
  currentLang: Language;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ currentLang }) => {
  const t = TRANSLATIONS[currentLang];
  const whatsappUrl = getWhatsAppUrl(currentLang);
  const isRTL = currentLang === 'ur';

  return (
    <section id="about" className="py-16 lg:py-24 bg-[#081226] border-b border-blue-950/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Column: Calm Consultation Image with Overlay Badges */}
          <div className="lg:col-span-5">
            <div className="relative rounded-3xl overflow-hidden border border-blue-900/60 bg-[#0c1a36] shadow-2xl">
              <img
                src={consultationRoomImage}
                alt="Personal guidance consultation room"
                className="w-full h-[360px] sm:h-[440px] object-cover"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#060e20] via-transparent to-transparent" />
              
              {/* Image Footer Badges */}
              <div className="absolute bottom-0 inset-x-0 p-6">
                <div className="p-3.5 rounded-2xl bg-[#060e20]/90 border border-blue-900/70 backdrop-blur-md">
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-[#facc15] shrink-0" />
                    <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#facc15]">
                      {t.about.experienceBadge}
                    </span>
                  </div>
                  <p className="mt-1 text-xs font-medium text-slate-300">
                    {t.about.nonClinicalBadge}
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Stat Pill Cards Below Image */}
            <div className="mt-4 grid grid-cols-2 gap-3">
              <div className="p-4 rounded-2xl bg-[#0c1a36] border border-blue-900/60 text-center">
                <div className="flex items-center justify-center gap-1.5 text-[#facc15]">
                  <Award className="w-4 h-4" />
                  <span className="text-2xl font-black font-mono">{t.about.statYearsNumber}</span>
                </div>
                <p className="mt-1 text-xs font-semibold text-slate-300">
                  {t.about.statYearsLabel}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-gradient-to-b from-[#0e2246] to-[#0c1a36] border border-emerald-500/40 text-center relative overflow-hidden shadow-lg shadow-emerald-950/20">
                <div className="flex items-center justify-center gap-1.5 text-emerald-400">
                  <Users className="w-4 h-4" />
                  <span className="text-xl sm:text-2xl font-black font-mono">{t.about.statGuidedNumber}</span>
                </div>
                <p className="mt-1 text-xs font-bold text-white">
                  {t.about.statGuidedLabel}
                </p>
                <div className="absolute top-1 right-1">
                  <Sparkles className="w-3 h-3 text-[#facc15] opacity-70" />
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Experience & Guided Text */}
          <div className="lg:col-span-7 space-y-6">
            
            <div>
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-wider uppercase text-emerald-400 font-mono bg-emerald-950/40 border border-emerald-800/40 px-3 py-1 rounded-full">
                <Sparkles className="w-3.5 h-3.5 text-[#facc15]" />
                {t.about.badge}
              </span>
              
              {/* Heading: 9 Years of Experience. Thousands of People Guided. */}
              <h2 className="mt-3 text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight leading-tight">
                {t.about.heading}
              </h2>
              
              <div className="w-20 h-1 bg-gradient-to-r from-blue-500 via-[#facc15] to-emerald-400 mt-3 rounded-full" />
            </div>

            {/* Paragraph 1 */}
            <p className="text-slate-200 text-base sm:text-lg leading-relaxed">
              {t.about.p1}
            </p>

            {/* Highlighted Banner for "Thousands of People Guided" & Paragraph 2 */}
            <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#0c1a36] to-[#0d2244] border-l-4 border-l-[#facc15] border-y border-r border-blue-900/60 shadow-lg">
              <div className="flex items-start gap-3">
                <Users className="w-5 h-5 text-[#facc15] shrink-0 mt-0.5" />
                <div>
                  <p className="text-white text-base sm:text-lg font-medium leading-relaxed">
                    {t.about.p2}
                  </p>
                </div>
              </div>
            </div>

            {/* Paragraph 3 */}
            <p className="text-slate-200 text-base sm:text-lg leading-relaxed">
              {t.about.p3}
            </p>

            {/* Inspiring Callout: You Are Not Alone. I Am Here to Guide You. */}
            <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-950/50 via-[#0c1a36] to-blue-950/50 border border-emerald-500/40 text-center sm:text-left flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl shadow-emerald-950/30">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center shrink-0">
                  <HeartHandshake className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <p className="text-lg sm:text-xl font-black text-white tracking-tight">
                    {t.about.callout}
                  </p>
                  <p className="text-xs text-emerald-300/90 font-medium">
                    {isRTL ? 'مجھ سے واٹس ایپ پر براہِ راست بات کریں' : 'Personal 1-on-1 guidance is one click away'}
                  </p>
                </div>
              </div>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="shrink-0 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold text-white bg-[#25D366] hover:bg-[#20bd5a] transition-all shadow-md active:scale-95 whitespace-nowrap"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>{t.contact.whatsappButton}</span>
              </a>
            </div>

            {/* Non-clinical disclaimer note */}
            <div className="p-3.5 rounded-xl bg-[#060e20]/80 border border-blue-900/40 text-xs text-slate-400 flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
              <p>
                {t.about.disclaimer}
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
