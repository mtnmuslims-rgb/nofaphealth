import React from 'react';
import { Language, TRANSLATIONS, getWhatsAppUrl, OFFICIAL_PHONE } from '../data/translations';
import { MessageCircle, ShieldCheck, HeartHandshake, ArrowRight } from 'lucide-react';
import heroImage from '../assets/images/hero_thoughtful_man_window_1793958466790.jpg';

interface HeroProps {
  currentLang: Language;
}

export const Hero: React.FC<HeroProps> = ({ currentLang }) => {
  const t = TRANSLATIONS[currentLang];
  const whatsappUrl = getWhatsAppUrl(currentLang);
  const isRTL = currentLang === 'ur';

  return (
    <section id="home" className="relative overflow-hidden bg-[#060e20] pt-12 pb-20 lg:pt-20 lg:pb-28 border-b border-blue-950/80">
      
      {/* Background ambient lighting */}
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute -top-40 left-1/4 w-[600px] h-[500px] bg-blue-600/15 blur-3xl opacity-70"
      />
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute -top-40 right-1/4 w-[600px] h-[500px] bg-emerald-500/10 blur-3xl opacity-60"
      />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Core Messaging & Prominent WhatsApp Button */}
          <div className="lg:col-span-7 flex flex-col justify-center text-center lg:text-left">
            
            {/* Brand Logo & Name Lockup */}
            <div className="mb-5 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5">
              <div className="w-16 h-16 sm:w-18 sm:h-18 rounded-full p-1 bg-gradient-to-tr from-blue-600 via-emerald-400 to-[#facc15] shadow-xl shadow-blue-950/80 shrink-0">
                <img
                  src="/assets/aistudio/Glossy_Nofap_Health_Wellness_Badge_0df9b0fb.png"
                  alt="NoFap Health Badge"
                  className="w-full h-full object-contain rounded-full bg-white"
                  loading="eager"
                />
              </div>
              <div className="flex flex-col">
                <span className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                  NOFAP <span className="text-[#facc15]">HEALTH</span>
                </span>
                <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider font-mono">
                  {t.hero.brandTagline}
                </span>
              </div>
            </div>

            {/* Main Heading */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-white leading-[1.15] tracking-tight [text-wrap:balance]">
              {t.hero.heading}
            </h1>

            {/* Short Description */}
            <p className="mt-5 text-base sm:text-lg text-slate-200 leading-relaxed max-w-2xl mx-auto lg:mx-0 font-normal">
              {t.hero.description}
            </p>

            {/* Prominent WhatsApp Button Directly Below Description */}
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-8 py-4 text-base sm:text-lg font-black text-white bg-[#25D366] hover:bg-[#20bd5a] active:scale-[0.98] rounded-2xl transition-all shadow-xl shadow-emerald-950/60 flex items-center justify-center gap-3 border-2 border-emerald-400/40 group"
              >
                <MessageCircle className="w-6 h-6 fill-white shrink-0 group-hover:scale-110 transition-transform" />
                <span>{t.hero.whatsappButton}</span>
                <ArrowRight className={`w-5 h-5 shrink-0 ${isRTL ? 'rotate-180' : ''}`} />
              </a>

              <a
                href="#guidance"
                className="w-full sm:w-auto px-6 py-4 text-sm sm:text-base font-bold text-slate-200 bg-[#0c1a36]/90 border border-blue-800/80 rounded-2xl hover:bg-blue-900/60 hover:text-white transition-all text-center"
              >
                {t.nav.guidance}
              </a>
            </div>

            {/* One-Click Notice */}
            <div className="mt-6 flex items-center justify-center lg:justify-start gap-2 text-xs font-mono font-bold text-[#facc15]">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{t.hero.oneClickNotice}</span>
            </div>

            <p className="mt-2 text-xs text-slate-400 font-mono">
              WhatsApp: <span className="text-white font-bold">{OFFICIAL_PHONE}</span>
            </p>

          </div>

          {/* Right Column: High Quality Visual Asset */}
          <div className="lg:col-span-5 flex items-center justify-center">
            <div className="relative w-full max-w-md lg:max-w-none">
              
              <div 
                aria-hidden="true" 
                className="absolute -inset-1 rounded-3xl bg-gradient-to-r from-blue-600/30 via-emerald-400/20 to-[#facc15]/30 opacity-70 blur-lg"
              />

              <div className="relative overflow-hidden rounded-3xl border border-blue-900/80 bg-[#0c1a36] shadow-2xl">
                <img
                  src={heroImage}
                  alt="NoFap Health Guidance"
                  className="w-full h-[360px] sm:h-[420px] object-cover object-center"
                  loading="eager"
                  referrerPolicy="no-referrer"
                />
                
                <div className="absolute inset-0 bg-gradient-to-t from-[#060e20] via-[#060e20]/30 to-transparent" />

                <div className="absolute bottom-0 inset-x-0 p-6 text-left">
                  <div className="p-3.5 rounded-2xl bg-[#060e20]/90 border border-blue-900/60 backdrop-blur-sm">
                    <p className="text-xs sm:text-sm font-semibold text-white leading-snug">
                      {isRTL
                        ? 'رازدارانہ، باوقار اور مستقل ذاتی رہنمائی برائے مثبت طرزِ زندگی'
                        : 'Private, dignified, and consistent personal guidance for a healthier life.'}
                    </p>
                    <div className="mt-2 flex items-center justify-between text-[11px] text-slate-300">
                      <span className="text-emerald-400 font-bold">WhatsApp: {OFFICIAL_PHONE}</span>
                      <span className="text-[#facc15] font-semibold">{isRTL ? '9 سالہ تجربہ' : '9 Yrs Exp'}</span>
                    </div>
                  </div>
                </div>

              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
