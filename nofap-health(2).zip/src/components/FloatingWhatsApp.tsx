import React from 'react';
import { Language, TRANSLATIONS, getWhatsAppUrl, OFFICIAL_PHONE } from '../data/translations';
import { MessageCircle } from 'lucide-react';

interface FloatingWhatsAppProps {
  currentLang: Language;
}

export const FloatingWhatsApp: React.FC<FloatingWhatsAppProps> = ({ currentLang }) => {
  const t = TRANSLATIONS[currentLang];
  const whatsappUrl = getWhatsAppUrl(currentLang);
  const isRTL = currentLang === 'ur';

  return (
    <aside
      aria-label="WhatsApp quick contact"
      className={`fixed z-50 bottom-5 ${isRTL ? 'left-5' : 'right-5'} flex items-center group`}
    >
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-3 p-3.5 sm:px-5 sm:py-3.5 bg-[#25D366] hover:bg-[#20bd5a] text-white rounded-full shadow-2xl shadow-emerald-950/80 border-2 border-emerald-300/60 transition-all duration-300 hover:scale-105 active:scale-95"
        title="Chat on WhatsApp: +92 309 8106340"
      >
        {/* Pulsing ring animation */}
        <span className="relative flex h-6 w-6 shrink-0">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-70" />
          <MessageCircle className="relative inline-flex h-6 w-6 fill-white" />
        </span>

        {/* Text visible on desktop, hidden on tiny screens to remain clean */}
        <span className="hidden sm:inline font-black text-sm tracking-wide whitespace-nowrap">
          {t.floatingButtonTooltip}
        </span>
      </a>
    </aside>
  );
};
