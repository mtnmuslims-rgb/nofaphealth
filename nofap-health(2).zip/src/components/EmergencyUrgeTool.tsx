import React, { useState, useEffect } from 'react';
import { ShieldAlert, Play, Pause, RotateCcw, Check, Sparkles, Wind, Droplets, Dumbbell, Footprints } from 'lucide-react';

export const EmergencyUrgeTool: React.FC = () => {
  // Timer state for the 15-minute urge surfing wave
  const [secondsLeft, setSecondsLeft] = useState<number>(15 * 60); // 15 mins
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);

  // Breathing pacer state (4s inhale, 7s hold, 8s exhale)
  const [breathPhase, setBreathPhase] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');
  const [breathCount, setBreathCount] = useState<number>(4);
  const [isBreathingActive, setIsBreathingActive] = useState<boolean>(false);

  // Somatic 5-4-3-2-1 checklist
  const [groundingCheck, setGroundingCheck] = useState<{ [key: string]: boolean }>({});

  // Active sub-tab
  const [activeTool, setActiveTool] = useState<'timer' | 'breathing' | 'grounding' | 'shock'>('timer');

  // Urge surfing countdown
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isTimerRunning && secondsLeft > 0) {
      interval = setInterval(() => {
        setSecondsLeft((prev) => prev - 1);
      }, 1000);
    } else if (secondsLeft === 0) {
      setIsTimerRunning(false);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning, secondsLeft]);

  // Breathing pacer loop
  useEffect(() => {
    if (!isBreathingActive) return;

    let timer: NodeJS.Timeout;
    if (breathPhase === 'Inhale') {
      if (breathCount > 1) {
        timer = setTimeout(() => setBreathCount(breathCount - 1), 1000);
      } else {
        setBreathPhase('Hold');
        setBreathCount(7);
      }
    } else if (breathPhase === 'Hold') {
      if (breathCount > 1) {
        timer = setTimeout(() => setBreathCount(breathCount - 1), 1000);
      } else {
        setBreathPhase('Exhale');
        setBreathCount(8);
      }
    } else if (breathPhase === 'Exhale') {
      if (breathCount > 1) {
        timer = setTimeout(() => setBreathCount(breathCount - 1), 1000);
      } else {
        setBreathPhase('Inhale');
        setBreathCount(4);
      }
    }

    return () => clearTimeout(timer);
  }, [isBreathingActive, breathPhase, breathCount]);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const resetTimer = () => {
    setIsTimerRunning(false);
    setSecondsLeft(15 * 60);
  };

  const toggleGrounding = (id: string) => {
    setGroundingCheck((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const groundingItems = [
    { id: 'see', count: 5, label: 'Look around your room and name 5 things you can visually see right now' },
    { id: 'touch', count: 4, label: 'Notice 4 physical textures you can feel (your shirt, cold desk, the floor)' },
    { id: 'hear', count: 3, label: 'Listen carefully and identify 3 subtle sounds in your environment' },
    { id: 'smell', count: 2, label: 'Notice 2 distinct scents or take a deep sniff of fresh air or coffee' },
    { id: 'taste', count: 1, label: 'Notice 1 taste in your mouth or sip a cold glass of fresh water' },
  ];

  return (
    <section id="emergency-tool" className="py-20 lg:py-28 bg-[#060e20] border-b border-blue-950/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header with Urge SOS indicator */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-rose-950/60 border border-rose-800/80 text-rose-300 text-xs font-bold uppercase tracking-wider mb-3">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span>Interactive Practical Tool</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight [text-wrap:balance]">
            Urge Surfing & Emergency Reset Assistant
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-200 leading-relaxed">
            Experiencing an intense craving right now? <span className="text-emerald-400 font-semibold">Do not fight it with tension.</span> Ride the neurochemical wave until your rational brain comes back online.
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-blue-500 via-[#facc15] to-emerald-400 mx-auto mt-4 rounded-full" />
        </div>

        {/* Tool Container */}
        <div className="mt-12 max-w-3xl mx-auto rounded-3xl border border-blue-900/60 bg-[#0c1a36]/90 shadow-2xl overflow-hidden">
          
          {/* Sub-Nav Controls */}
          <div className="flex border-b border-blue-900/50 overflow-x-auto p-2 bg-[#060e20]/60 gap-1.5">
            <button
              onClick={() => setActiveTool('timer')}
              className={`flex-1 py-2.5 px-3.5 text-xs sm:text-sm font-bold rounded-xl transition-all whitespace-nowrap cursor-pointer flex items-center justify-center gap-2 ${
                activeTool === 'timer'
                  ? 'bg-gradient-to-r from-[#facc15] to-[#eab308] text-slate-950 shadow-md border border-amber-300/60'
                  : 'text-slate-300 hover:text-white hover:bg-blue-900/40'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>15-Min Urge Wave</span>
            </button>

            <button
              onClick={() => setActiveTool('breathing')}
              className={`flex-1 py-2.5 px-3.5 text-xs sm:text-sm font-bold rounded-xl transition-all whitespace-nowrap cursor-pointer flex items-center justify-center gap-2 ${
                activeTool === 'breathing'
                  ? 'bg-gradient-to-r from-[#facc15] to-[#eab308] text-slate-950 shadow-md border border-amber-300/60'
                  : 'text-slate-300 hover:text-white hover:bg-blue-900/40'
              }`}
            >
              <Wind className="w-4 h-4" />
              <span>4-7-8 Breathing Pacer</span>
            </button>

            <button
              onClick={() => setActiveTool('grounding')}
              className={`flex-1 py-2.5 px-3.5 text-xs sm:text-sm font-bold rounded-xl transition-all whitespace-nowrap cursor-pointer flex items-center justify-center gap-2 ${
                activeTool === 'grounding'
                  ? 'bg-gradient-to-r from-[#facc15] to-[#eab308] text-slate-950 shadow-md border border-amber-300/60'
                  : 'text-slate-300 hover:text-white hover:bg-blue-900/40'
              }`}
            >
              <Check className="w-4 h-4" />
              <span>5-4-3-2-1 Grounding</span>
            </button>

            <button
              onClick={() => setActiveTool('shock')}
              className={`flex-1 py-2.5 px-3.5 text-xs sm:text-sm font-bold rounded-xl transition-all whitespace-nowrap cursor-pointer flex items-center justify-center gap-2 ${
                activeTool === 'shock'
                  ? 'bg-gradient-to-r from-[#facc15] to-[#eab308] text-slate-950 shadow-md border border-amber-300/60'
                  : 'text-slate-300 hover:text-white hover:bg-blue-900/40'
              }`}
            >
              <Droplets className="w-4 h-4" />
              <span>Physical Shock Actions</span>
            </button>
          </div>

          {/* Tab 1: 15-Minute Urge Wave Timer */}
          {activeTool === 'timer' && (
            <div className="p-6 sm:p-10 text-center space-y-6">
              <div>
                <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-semibold">
                  The Neurochemical Clock
                </span>
                <p className="mt-1 text-sm text-slate-200 max-w-md mx-auto">
                  Research shows peak cravings crest and fade within 12–15 minutes if you do not browse or feed them.
                </p>
              </div>

              {/* Big Timer Display */}
              <div className="py-6">
                <div className="text-6xl sm:text-7xl font-mono font-black text-[#facc15] tracking-tight tabular-nums drop-shadow-md">
                  {formatTime(secondsLeft)}
                </div>
                <p className="mt-2 text-xs text-slate-300">
                  {isTimerRunning ? 'Wave is actively subsiding... Stay in the room, breathe slowly.' : 'Click Start to ride this 15-minute wave.'}
                </p>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-center gap-4">
                <button
                  onClick={() => setIsTimerRunning(!isTimerRunning)}
                  className="px-7 py-3 rounded-xl text-sm font-extrabold text-slate-950 bg-gradient-to-r from-[#facc15] to-[#eab308] hover:from-amber-300 hover:to-amber-400 transition-all shadow-md flex items-center gap-2 cursor-pointer border border-amber-300/50"
                >
                  {isTimerRunning ? (
                    <>
                      <Pause className="w-4 h-4" />
                      <span>Pause Wave</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 fill-slate-950" />
                      <span>Start Urge Surfing</span>
                    </>
                  )}
                </button>

                <button
                  onClick={resetTimer}
                  className="p-3 rounded-xl text-sm font-semibold text-slate-300 bg-[#10244c] hover:text-white hover:bg-blue-900/80 transition-all cursor-pointer border border-blue-800/60"
                  title="Reset Timer"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>

              {/* Guidance Tips During Timer */}
              <div className="p-5 rounded-2xl bg-[#060e20]/80 border border-blue-900/50 text-left text-xs sm:text-sm text-slate-200 space-y-2">
                <p className="font-bold text-white flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span>How to surf this wave:</span>
                </p>
                <p>1. Notice the physical tension in your chest or stomach without judging it.</p>
                <p>2. Do not open any browser tabs or check your phone.</p>
                <p>3. Remind yourself: &ldquo;This feeling is simply dopamine seeking novelty. It will peak and dissolve.&rdquo;</p>
              </div>
            </div>
          )}

          {/* Tab 2: 4-7-8 Breathing Pacer */}
          {activeTool === 'breathing' && (
            <div className="p-6 sm:p-10 text-center space-y-8">
              <div>
                <span className="text-xs font-mono uppercase tracking-widest text-slate-400">
                  Parasympathetic Vagal Reset
                </span>
                <p className="mt-1 text-sm text-slate-300 max-w-md mx-auto">
                  The 4-7-8 rhythm drops your sympathetic heart rate and switches blood back into the prefrontal cortex.
                </p>
              </div>

              {/* Animated Circle Container */}
              <div className="flex flex-col items-center justify-center py-6">
                <div
                  className={`w-44 h-44 rounded-full border-4 flex flex-col items-center justify-center transition-all duration-1000 ${
                    breathPhase === 'Inhale'
                      ? 'border-emerald-400 bg-emerald-950/40 scale-110 shadow-2xl shadow-emerald-500/20'
                      : breathPhase === 'Hold'
                      ? 'border-amber-400 bg-amber-950/40 scale-105 shadow-2xl shadow-amber-500/20'
                      : 'border-blue-400 bg-blue-950/40 scale-95 shadow-2xl shadow-blue-500/20'
                  }`}
                >
                  <span className="text-xs font-mono uppercase tracking-wider text-slate-300 font-semibold">
                    {isBreathingActive ? breathPhase : 'Ready'}
                  </span>
                  <span className="text-4xl font-extrabold text-white font-mono mt-1">
                    {isBreathingActive ? breathCount : '4-7-8'}
                  </span>
                  <span className="text-[11px] text-slate-400 mt-1">
                    {isBreathingActive
                      ? breathPhase === 'Inhale'
                        ? 'Through nose'
                        : breathPhase === 'Hold'
                        ? 'Keep relaxed'
                        : 'Through mouth'
                      : 'Press Start'}
                  </span>
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-center gap-4">
                <button
                  onClick={() => setIsBreathingActive(!isBreathingActive)}
                  className="px-6 py-3 rounded-lg text-sm font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition-all shadow-md flex items-center gap-2 cursor-pointer"
                >
                  {isBreathingActive ? (
                    <>
                      <Pause className="w-4 h-4" />
                      <span>Stop Breathing</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4" />
                      <span>Start 4-7-8 Pacer</span>
                    </>
                  )}
                </button>
              </div>

              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Complete at least 4 cycles (about 2 minutes). Feel your shoulders dropping away from your ears.
              </p>
            </div>
          )}

          {/* Tab 3: 5-4-3-2-1 Sensory Grounding */}
          {activeTool === 'grounding' && (
            <div className="p-6 sm:p-10 space-y-6">
              <div className="text-center">
                <span className="text-xs font-mono uppercase tracking-widest text-slate-400">
                  Somatic Redirection
                </span>
                <p className="mt-1 text-sm text-slate-300 max-w-md mx-auto">
                  Grounding pulls your brain out of fantasy and anchors your consciousness in immediate physical reality.
                </p>
              </div>

              <div className="space-y-3 pt-2">
                {groundingItems.map((item) => {
                  const isChecked = !!groundingCheck[item.id];
                  return (
                    <div
                      key={item.id}
                      onClick={() => toggleGrounding(item.id)}
                      className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center gap-3.5 ${
                        isChecked
                          ? 'bg-emerald-950/30 border-emerald-800 text-slate-200'
                          : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className={`w-6 h-6 rounded-md border flex items-center justify-center text-xs font-bold shrink-0 transition-colors ${
                        isChecked ? 'bg-emerald-500 border-emerald-400 text-slate-950' : 'border-slate-700 text-slate-400'
                      }`}>
                        {isChecked ? <Check className="w-4 h-4" /> : item.count}
                      </div>
                      <span className={`text-xs sm:text-sm ${isChecked ? 'line-through text-slate-400' : ''}`}>
                        {item.label}
                      </span>
                    </div>
                  );
                })}
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => setGroundingCheck({})}
                  className="text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  Reset Checklist
                </button>
              </div>
            </div>
          )}

          {/* Tab 4: Physical Shock Actions */}
          {activeTool === 'shock' && (
            <div className="p-6 sm:p-10 space-y-6">
              <div className="text-center">
                <span className="text-xs font-mono uppercase tracking-widest text-slate-400">
                  Immediate Physical Interventions
                </span>
                <p className="mt-1 text-sm text-slate-300 max-w-md mx-auto">
                  When an urge is overwhelming, verbal thinking is not enough. You must activate major muscle groups or cold receptors.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start gap-3">
                  <div className="p-2.5 rounded-lg bg-blue-950/60 text-blue-400 border border-blue-800/40 shrink-0">
                    <Droplets className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">The Dive Reflex</h4>
                    <p className="mt-1 text-xs text-slate-300 leading-relaxed">
                      Splash ice-cold water onto your face for 30 seconds. Cold water on trigeminal facial nerves instantly drops heart rate by 15–20 BPM.
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start gap-3">
                  <div className="p-2.5 rounded-lg bg-amber-950/60 text-amber-400 border border-amber-800/40 shrink-0">
                    <Dumbbell className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">25 Fast Push-Ups</h4>
                    <p className="mt-1 text-xs text-slate-300 leading-relaxed">
                      Drop immediately to the floor. Pumping skeletal muscles draws pooled pelvic blood into chest, shoulders, and triceps.
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start gap-3">
                  <div className="p-2.5 rounded-lg bg-emerald-950/60 text-emerald-400 border border-emerald-800/40 shrink-0">
                    <Footprints className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Leave the Room Unplugged</h4>
                    <p className="mt-1 text-xs text-slate-300 leading-relaxed">
                      Leave your smartphone and computer behind. Walk into your kitchen, balcony, or step outside into the night air for 10 minutes.
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start gap-3">
                  <div className="p-2.5 rounded-lg bg-indigo-950/60 text-indigo-400 border border-indigo-800/40 shrink-0">
                    <Wind className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Call/Text Your Partner</h4>
                    <p className="mt-1 text-xs text-slate-300 leading-relaxed">
                      Send a brief one-line text to your accountability partner: &ldquo;Wave hit. Step outside for 15 mins.&rdquo; Stating it breaks secrecy.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

      </div>
    </section>
  );
};
