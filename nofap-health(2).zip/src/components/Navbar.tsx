import React, { useState } from 'react';
import { Language, TRANSLATIONS, getWhatsAppUrl, OFFICIAL_PHONE } from '../data/translations';
import { MessageCircle, Menu, X, Globe } from 'lucide-react';

interface NavbarProps {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentLang, onLanguageChange }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = TRANSLATIONS[currentLang];
  const isRTL = currentLang === 'ur';

  const navLinks = [
    { label: t.nav.home, href: '#home' },
    { label: t.nav.about, href: '#about' },
    { label: t.nav.education, href: '#education' },
    { label: t.nav.guidance, href: '#guidance' },
    { label: t.nav.contact, href: '#contact' },
  ];

  const whatsappUrl = getWhatsAppUrl(currentLang);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-blue-950/80 bg-[#060e20]/95 backdrop-blur-md">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        
        {/* Brand Lockup with Logo Badge */}
        <a
          href="#home"
          className="flex items-center gap-3 transition-opacity hover:opacity-95 whitespace-nowrap shrink-0 group"
        >
          <div className="relative w-11 h-11 sm:w-12 sm:h-12 rounded-full overflow-hidden p-0.5 bg-gradient-to-tr from-blue-600 via-emerald-400 to-[#facc15] shadow-md shrink-0">
            <img
              src="/assets/aistudio/Glossy_Nofap_Health_Wellness_Badge_0df9b0fb.png"
              alt="NoFap Health Logo"
              className="w-full h-full object-contain rounded-full bg-white"
              loading="eager"
            />
          </div>
          <div className="flex flex-col">
            <div className="text-xl sm:text-2xl font-black tracking-tight flex items-center leading-none">
              <span className="text-white font-extrabold">NOFAP</span>
              <span className="text-[#facc15] ml-1.5 font-extrabold">HEALTH</span>
            </div>
            <span className="text-[10px] sm:text-[11px] font-semibold text-emerald-400 tracking-wider font-mono uppercase mt-0.5">
              {isRTL ? 'صحت مند رہیں • بہتر بنیں' : 'Live Healthy • Be Better'}
            </span>
          </div>
        </a>

        {/* 4 Clean Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-200">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="whitespace-nowrap shrink-0 transition-colors hover:text-[#facc15]"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Language Switcher + WhatsApp Button */}
        <div className="flex items-center gap-3 shrink-0">
          
          {/* Clearly Visible Language Switcher: EN | اردو */}
          <div className="flex items-center rounded-xl bg-[#0c1a36] border border-blue-900/80 p-1 text-xs font-bold shadow-inner">
            <button
              type="button"
              onClick={() => onLanguageChange('en')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                currentLang === 'en'
                  ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Switch to English"
            >
              EN
            </button>
            <span className="text-slate-600 px-0.5 select-none">|</span>
            <button
              type="button"
              onClick={() => onLanguageChange('ur')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer font-serif ${
                currentLang === 'ur'
                  ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="اردو زبان منتخب کریں"
            >
              اردو
            </button>
          </div>

          {/* Primary WhatsApp Button in Navbar */}
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-bold text-white bg-[#25D366] hover:bg-[#20bd5a] rounded-xl transition-all shadow-md shadow-emerald-950/40 whitespace-nowrap shrink-0"
          >
            <MessageCircle className="w-4 h-4 fill-white" />
            <span>{t.nav.whatsappButton}</span>
          </a>

          {/* Mobile hamburger button */}
          <div className="flex md:hidden items-center">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-300 hover:text-white focus:outline-none rounded-lg bg-[#0c1a36] border border-blue-900/60"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>

      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="border-b border-blue-900/60 bg-[#060e20] px-4 pt-3 pb-6 md:hidden">
          <nav className="flex flex-col space-y-3">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="py-2 text-base font-semibold text-slate-200 hover:text-[#facc15] transition-colors"
              >
                {link.label}
              </a>
            ))}
            
            <div className="pt-3 border-t border-blue-900/50 flex flex-col gap-3">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full flex items-center justify-center gap-2 py-3 text-sm font-bold text-white bg-[#25D366] hover:bg-[#20bd5a] rounded-xl transition-colors shadow-md text-center"
              >
                <MessageCircle className="w-5 h-5 fill-white" />
                <span>{t.nav.whatsappButton}</span>
              </a>
              <p className="text-center text-xs text-slate-400 font-mono">
                {OFFICIAL_PHONE}
              </p>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
