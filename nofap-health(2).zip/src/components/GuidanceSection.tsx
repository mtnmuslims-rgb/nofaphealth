import React from 'react';
import { Language, TRANSLATIONS, getPlanWhatsAppUrl, OFFICIAL_PHONE } from '../data/translations';
import { MessageCircle, ArrowRight, ShieldCheck, Clock, CheckCircle2 } from 'lucide-react';

interface GuidanceSectionProps {
  currentLang: Language;
}

export const GuidanceSection: React.FC<GuidanceSectionProps> = ({ currentLang }) => {
  const t = TRANSLATIONS[currentLang];
  const plansData = t.guidancePlans;
  const isRTL = currentLang === 'ur';

  const weeklyUrl = getPlanWhatsAppUrl('weekly', currentLang);
  const fifteenUrl = getPlanWhatsAppUrl('fifteen', currentLang);
  const monthlyUrl = getPlanWhatsAppUrl('monthly', currentLang);

  return (
    <section id="guidance" className="py-16 lg:py-24 bg-[#060e20] border-b border-blue-950/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <span className="text-xs font-semibold tracking-wider uppercase text-emerald-400 font-mono">
            {t.accountability.badge}
          </span>
          <h2 className="mt-2 text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight [text-wrap:balance]">
            {t.accountability.heading}
          </h2>
          <div className="w-16 h-1 bg-gradient-to-r from-blue-500 via-[#facc15] to-emerald-400 mx-auto mt-4 rounded-full" />
        </div>

        {/* Narrative */}
        <div className="mt-8 max-w-3xl mx-auto space-y-4 text-slate-200 text-base sm:text-lg leading-relaxed text-center">
          <p>
            {t.accountability.p1}
          </p>
          <p className="font-semibold text-white">
            {t.accountability.p2}
          </p>
          <p>
            {t.accountability.p3}
          </p>
        </div>

        {/* Highlight Statement Banner */}
        <div className="mt-10 max-w-3xl mx-auto">
          <div className="relative overflow-hidden rounded-2xl border-2 border-[#facc15]/60 bg-gradient-to-r from-[#0c224d] via-[#091838] to-[#061129] p-6 sm:p-8 shadow-2xl text-center">
            <span className="text-xs font-mono uppercase tracking-widest text-[#facc15] font-bold block mb-1">
              KEY PRINCIPLE
            </span>
            <p className="text-xl sm:text-2xl md:text-3xl font-black text-white tracking-tight leading-snug">
              &ldquo;{t.accountability.highlight}&rdquo;
            </p>
          </div>
        </div>

        {/* Three Flexible Guidance Plans Subheading */}
        <div className="mt-20 text-center max-w-3xl mx-auto">
          <span className="text-xs font-semibold tracking-wider uppercase text-[#facc15] font-mono">
            {plansData.badge}
          </span>
          <h3 className="mt-2 text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight">
            {plansData.heading}
          </h3>
          <p className="mt-3 text-base sm:text-lg text-slate-300 max-w-2xl mx-auto">
            {plansData.description}
          </p>
        </div>

        {/* Three Plan Cards Grid */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch max-w-6xl mx-auto">
          
          {/* Card 1: WEEKLY GUIDANCE */}
          <div className="rounded-3xl bg-[#0c1a36]/80 border border-blue-900/60 p-6 sm:p-8 flex flex-col justify-between shadow-xl hover:border-blue-700/80 transition-all hover:-translate-y-1">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-mono tracking-wider text-emerald-400 font-bold">
                  {plansData.plans.weekly.duration}
                </span>
                <Clock className="w-4 h-4 text-slate-400" />
              </div>

              <h4 className="text-xl sm:text-2xl font-black text-white">
                {plansData.plans.weekly.title}
              </h4>

              <p className="text-sm sm:text-base text-slate-300 leading-relaxed min-h-[4.5rem]">
                {plansData.plans.weekly.description}
              </p>

              <div className="pt-4 border-t border-blue-900/50 space-y-2 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>One-to-one personal guidance</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Weekly accountability support</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Direct WhatsApp communication</span>
                </div>
              </div>
            </div>

            <div className="pt-6">
              <a
                href={weeklyUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 px-4 text-sm sm:text-base font-extrabold text-white bg-[#25D366] hover:bg-[#20bd5a] active:scale-[0.98] rounded-xl transition-all shadow-md shadow-emerald-950/50 flex items-center justify-center gap-2 border border-emerald-400/40 text-center group"
              >
                <MessageCircle className="w-5 h-5 fill-white shrink-0 group-hover:scale-110 transition-transform" />
                <span>{plansData.plans.weekly.buttonText}</span>
                <ArrowRight className={`w-4 h-4 shrink-0 ${isRTL ? 'rotate-180' : ''}`} />
              </a>
            </div>
          </div>

          {/* Card 2: 15-DAY GUIDANCE (Featured Card) */}
          <div className="relative rounded-3xl bg-gradient-to-b from-[#0f2452] via-[#0b1b3d] to-[#07132b] border-2 border-[#facc15] p-6 sm:p-8 flex flex-col justify-between shadow-2xl shadow-blue-950/90 lg:-translate-y-2">
            
            {/* Featured ribbon pill */}
            <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-[#facc15] to-[#eab308] text-slate-950 text-xs font-black uppercase tracking-wider py-1 px-4 rounded-full shadow-md whitespace-nowrap">
              {currentLang === 'ur' ? 'تجویز کردہ انتخاب' : 'Popular Choice'}
            </div>

            <div className="space-y-4 pt-2">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-mono tracking-wider text-[#facc15] font-black">
                  {plansData.plans.fifteen.duration}
                </span>
                <Clock className="w-4 h-4 text-[#facc15]" />
              </div>

              <h4 className="text-xl sm:text-2xl font-black text-white">
                {plansData.plans.fifteen.title}
              </h4>

              <p className="text-sm sm:text-base text-slate-200 leading-relaxed min-h-[4.5rem]">
                {plansData.plans.fifteen.description}
              </p>

              <div className="pt-4 border-t border-blue-900/60 space-y-2 text-xs text-slate-200">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#facc15] shrink-0" />
                  <span>15 days continuous guidance</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#facc15] shrink-0" />
                  <span>Personal trigger identification</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#facc15] shrink-0" />
                  <span>Habit-building strategies</span>
                </div>
              </div>
            </div>

            <div className="pt-6">
              <a
                href={fifteenUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-4 px-4 text-base font-black text-white bg-[#25D366] hover:bg-[#20bd5a] active:scale-[0.98] rounded-xl transition-all shadow-lg shadow-emerald-950/60 flex items-center justify-center gap-2 border-2 border-emerald-400/50 text-center group"
              >
                <MessageCircle className="w-5 h-5 fill-white shrink-0 group-hover:scale-110 transition-transform" />
                <span>{plansData.plans.fifteen.buttonText}</span>
                <ArrowRight className={`w-4 h-4 shrink-0 ${isRTL ? 'rotate-180' : ''}`} />
              </a>
            </div>
          </div>

          {/* Card 3: MONTHLY GUIDANCE */}
          <div className="rounded-3xl bg-[#0c1a36]/80 border border-blue-900/60 p-6 sm:p-8 flex flex-col justify-between shadow-xl hover:border-blue-700/80 transition-all hover:-translate-y-1">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-mono tracking-wider text-emerald-400 font-bold">
                  {plansData.plans.monthly.duration}
                </span>
                <Clock className="w-4 h-4 text-slate-400" />
              </div>

              <h4 className="text-xl sm:text-2xl font-black text-white">
                {plansData.plans.monthly.title}
              </h4>

              <p className="text-sm sm:text-base text-slate-300 leading-relaxed min-h-[4.5rem]">
                {plansData.plans.monthly.description}
              </p>

              <div className="pt-4 border-t border-blue-900/50 space-y-2 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Full 1-month dedicated mentorship</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Deep lifestyle restructuring</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Regular progress discussions</span>
                </div>
              </div>
            </div>

            <div className="pt-6">
              <a
                href={monthlyUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 px-4 text-sm sm:text-base font-extrabold text-white bg-[#25D366] hover:bg-[#20bd5a] active:scale-[0.98] rounded-xl transition-all shadow-md shadow-emerald-950/50 flex items-center justify-center gap-2 border border-emerald-400/40 text-center group"
              >
                <MessageCircle className="w-5 h-5 fill-white shrink-0 group-hover:scale-110 transition-transform" />
                <span>{plansData.plans.monthly.buttonText}</span>
                <ArrowRight className={`w-4 h-4 shrink-0 ${isRTL ? 'rotate-180' : ''}`} />
              </a>
            </div>
          </div>

        </div>

        {/* Reassurance note below cards */}
        <div className="mt-12 max-w-2xl mx-auto p-4 rounded-2xl bg-[#0c1a36]/70 border border-blue-900/60 text-center text-xs text-slate-300 flex items-center justify-center gap-2.5">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{plansData.discussionNote}</span>
        </div>

      </div>
    </section>
  );
};
