import React, { useState } from 'react';
import { FAQ_DATA } from '../data/faq';
import { ChevronDown, ChevronUp, HelpCircle } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIdx(openIdx === idx ? null : idx);
  };

  return (
    <section className="py-20 lg:py-28 bg-[#060e20] border-b border-blue-950/80">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto">
          <span className="text-xs font-semibold tracking-wider uppercase text-emerald-400 font-mono">
            FREQUENTLY ASKED QUESTIONS
          </span>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight [text-wrap:balance]">
            Honest Answers About Our Approach
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-200">
            Everything you need to know regarding confidentiality, session structure, non-clinical boundaries, and international scheduling.
          </p>
          <div className="w-16 h-1 bg-gradient-to-r from-blue-500 via-[#facc15] to-emerald-400 mx-auto mt-4 rounded-full" />
        </div>

        {/* Accordion List */}
        <div className="mt-14 space-y-3.5">
          {FAQ_DATA.map((item, idx) => {
            const isOpen = openIdx === idx;

            return (
              <div
                key={idx}
                className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                  isOpen
                    ? 'bg-[#0c1a36] border-amber-400/60 shadow-xl'
                    : 'bg-[#0c1a36]/60 border-blue-900/50 hover:border-blue-700/70'
                }`}
              >
                <button
                  type="button"
                  onClick={() => toggle(idx)}
                  className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono text-[#facc15] font-black">
                      0{idx + 1}.
                    </span>
                    <span className="text-base sm:text-lg font-bold text-white">
                      {item.question}
                    </span>
                  </div>
                  <div className="text-slate-300 shrink-0">
                    {isOpen ? <ChevronUp className="w-5 h-5 text-[#facc15]" /> : <ChevronDown className="w-5 h-5" />}
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-6 pt-0 text-sm sm:text-base text-slate-200 leading-relaxed border-t border-blue-900/50 mt-1 pt-4">
                    <p>{item.answer}</p>
                    <div className="mt-3 text-[11px] font-mono text-emerald-400 uppercase tracking-wider font-semibold">
                      Category: {item.category}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
