import React from 'react';
import { Language, TRANSLATIONS, getWhatsAppUrl } from '../data/translations';
import { 
  Milestone, 
  Target, 
  HelpCircle, 
  HeartHandshake, 
  Sparkles, 
  MessageCircle, 
  ArrowRight,
  ShieldAlert,
  ChevronRight,
  CheckCircle2
} from 'lucide-react';

interface ProgressMilestonesProps {
  currentLang: Language;
}

export const ProgressMilestones: React.FC<ProgressMilestonesProps> = ({ currentLang }) => {
  const t = TRANSLATIONS[currentLang];
  const ms = t.milestones;
  const whatsappUrl = getWhatsAppUrl(currentLang);
  const isRTL = currentLang === 'ur';

  const stageIcons = [
    { accent: 'from-amber-500/20 to-amber-600/10', border: 'border-amber-500/40', text: 'text-[#facc15]', dot: 'bg-[#facc15]' },
    { accent: 'from-blue-500/20 to-blue-600/10', border: 'border-blue-500/40', text: 'text-blue-400', dot: 'bg-blue-400' },
    { accent: 'from-purple-500/20 to-purple-600/10', border: 'border-purple-500/40', text: 'text-purple-400', dot: 'bg-purple-400' },
    { accent: 'from-emerald-500/20 to-emerald-600/10', border: 'border-emerald-500/40', text: 'text-emerald-400', dot: 'bg-emerald-400' },
  ];

  return (
    <section id="milestones" className="py-16 lg:py-24 bg-[#060e20] border-b border-blue-950/80 relative overflow-hidden">
      
      {/* Subtle ambient lighting */}
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-blue-600/5 blur-3xl rounded-full" 
      />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10 space-y-12">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto">
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-wider uppercase text-[#facc15] font-mono bg-amber-950/40 border border-amber-800/40 px-3 py-1 rounded-full">
            <Milestone className="w-3.5 h-3.5 text-[#facc15]" />
            {ms.badge}
          </span>

          <h2 className="mt-3 text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight [text-wrap:balance]">
            {ms.title}
          </h2>

          <div className="w-20 h-1 bg-gradient-to-r from-blue-500 via-[#facc15] to-emerald-400 mx-auto mt-4 rounded-full" />
          
          <p className="mt-4 text-base sm:text-lg text-slate-300 leading-relaxed font-normal">
            {ms.subheading}
          </p>
        </div>

        {/* 4-Stage Connected Visual Roadmap */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative">
          
          {ms.stages.map((stage, idx) => {
            const style = stageIcons[idx % stageIcons.length];

            return (
              <div
                key={idx}
                className={`p-6 rounded-3xl bg-gradient-to-b ${style.accent} to-[#071329] border ${style.border} shadow-xl flex flex-col justify-between space-y-5 hover:translate-y-[-2px] transition-all relative group`}
              >
                {/* Stage Header: Number & Days Badge */}
                <div className="flex items-center justify-between pb-3 border-b border-blue-900/50">
                  <div className="flex items-center gap-2">
                    <span className="text-xl sm:text-2xl font-black font-mono text-white/90">
                      {stage.stageNumber}
                    </span>
                    <span className={`w-2 h-2 rounded-full ${style.dot}`} />
                  </div>

                  <span className={`text-xs font-mono font-bold uppercase tracking-wider ${style.text} bg-[#0c1a36] px-2.5 py-1 rounded-lg border border-blue-900/60`}>
                    {stage.days}
                  </span>
                </div>

                {/* Stage Title */}
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-white tracking-tight leading-snug">
                    {stage.title}
                  </h3>
                </div>

                {/* 3 Detail Rows: Focus, Experience, Guidance Support */}
                <div className="space-y-3.5 text-xs sm:text-sm text-slate-300">
                  
                  {/* Focus */}
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-slate-200 font-semibold text-xs font-mono uppercase tracking-wider">
                      <Target className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                      <span>{isRTL ? 'بنیادی فوکس:' : 'Primary Focus:'}</span>
                    </div>
                    <p className="text-slate-300 leading-relaxed text-xs">
                      {stage.focus}
                    </p>
                  </div>

                  {/* Typical Experience */}
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-slate-200 font-semibold text-xs font-mono uppercase tracking-wider">
                      <HelpCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>{isRTL ? 'عام احساسات:' : 'What You May Feel:'}</span>
                    </div>
                    <p className="text-slate-300 leading-relaxed text-xs">
                      {stage.experience}
                    </p>
                  </div>

                  {/* Guidance Role */}
                  <div className="pt-2 border-t border-blue-900/40 space-y-1">
                    <div className="flex items-center gap-1.5 text-emerald-400 font-semibold text-xs font-mono uppercase tracking-wider">
                      <HeartHandshake className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>{isRTL ? 'ذاتی رہنمائی کا کردار:' : 'How Guidance Helps:'}</span>
                    </div>
                    <p className="text-slate-200 leading-relaxed text-xs font-medium">
                      {stage.guidanceSupport}
                    </p>
                  </div>

                </div>

                {/* Subdued Step Progress Footnote */}
                <div className="pt-2 text-[11px] font-mono text-slate-400 flex items-center justify-between">
                  <span>Stage {idx + 1} of 4</span>
                  {idx < 3 && (
                    <ChevronRight className={`w-3.5 h-3.5 text-slate-500 ${isRTL ? 'rotate-180' : ''}`} />
                  )}
                  {idx === 3 && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  )}
                </div>

              </div>
            );
          })}

        </div>

        {/* Reassuring Context Note & Non-linear Reminder */}
        <div className="p-4 sm:p-5 rounded-2xl bg-[#08152e] border border-blue-900/60 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-xs sm:text-sm text-slate-300">
            <ShieldAlert className="w-5 h-5 text-[#facc15] shrink-0" />
            <p className="leading-relaxed">
              {ms.note}
            </p>
          </div>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="shrink-0 inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#25D366] hover:bg-[#20bd5a] transition-all shadow-md whitespace-nowrap"
          >
            <MessageCircle className="w-3.5 h-3.5 fill-white" />
            <span>{isRTL ? 'اپنے مرحلے پر بات کریں' : 'Discuss Your Stage'}</span>
            <ArrowRight className={`w-3.5 h-3.5 ${isRTL ? 'rotate-180' : ''}`} />
          </a>
        </div>

      </div>
    </section>
  );
};
