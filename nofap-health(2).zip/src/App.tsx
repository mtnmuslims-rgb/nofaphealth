import React, { useState, useEffect } from 'react';
import { Language } from './data/translations';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { EducationSection } from './components/EducationSection';
import { ProgressMilestones } from './components/ProgressMilestones';
import { GuidanceSection } from './components/GuidanceSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';

export default function App() {
  const [currentLang, setCurrentLang] = useState<Language>(() => {
    const saved = localStorage.getItem('nofap_lang');
    return saved === 'ur' ? 'ur' : 'en';
  });

  const handleLanguageChange = (lang: Language) => {
    setCurrentLang(lang);
    localStorage.setItem('nofap_lang', lang);
  };

  // Sync RTL and lang attribute on documentElement
  useEffect(() => {
    document.documentElement.lang = currentLang;
    document.documentElement.dir = currentLang === 'ur' ? 'rtl' : 'ltr';
  }, [currentLang]);

  return (
    <div
      dir={currentLang === 'ur' ? 'rtl' : 'ltr'}
      className="min-h-screen bg-[#060e20] text-slate-100 flex flex-col font-sans selection:bg-[#facc15] selection:text-slate-950 transition-colors duration-200"
    >
      {/* Top Navigation with EN | اردو Switcher & WhatsApp CTA */}
      <Navbar
        currentLang={currentLang}
        onLanguageChange={handleLanguageChange}
      />

      <main className="flex-1">
        {/* 1. Home Section */}
        <Hero currentLang={currentLang} />

        {/* 2. About Me Section (9 Years Experience, Thousands Guided) */}
        <AboutSection currentLang={currentLang} />

        {/* 3. Educational Section & Personal Message & Privacy */}
        <EducationSection currentLang={currentLang} />

        {/* 4. Progress Milestones: Visual Roadmap of Habit Change */}
        <ProgressMilestones currentLang={currentLang} />

        {/* 5. One-to-One Personal Guidance Plans */}
        <GuidanceSection currentLang={currentLang} />

        {/* 5. Success Stories & Personal Guidance Impact (Anonymous) */}
        <TestimonialsSection currentLang={currentLang} />

        {/* 6. Contact Section (WhatsApp & Waseem Abbas Email) */}
        <ContactSection currentLang={currentLang} />
      </main>

      {/* Footer */}
      <Footer
        currentLang={currentLang}
        onLanguageChange={handleLanguageChange}
      />

      {/* Floating WhatsApp Quick Action Button */}
      <FloatingWhatsApp currentLang={currentLang} />
    </div>
  );
}
