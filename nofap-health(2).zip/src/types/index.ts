export interface Article {
  id: string;
  title: string;
  slug: string;
  category: 'Neurobiology' | 'Practical Strategies' | 'Habit Architecture' | 'Mindset & Psychology';
  readTime: string;
  publishedDate: string;
  excerpt: string;
  keyTakeaways: string[];
  content: string[];
  actionSteps: string[];
  image: string;
}

export interface VideoTalk {
  id: string;
  title: string;
  duration: string;
  category: string;
  description: string;
  keyMoments: { time: string; topic: string }[];
  summary: string;
  reflectionPrompt: string;
}

export interface GuidancePackage {
  id: string;
  title: string;
  badge?: string;
  tagline: string;
  duration: string;
  idealFor: string;
  features: string[];
  format: string;
  deliverables: string[];
}

export interface FaqItem {
  question: string;
  answer: string;
  category: 'Guidance & Sessions' | 'Privacy & Confidentiality' | 'Habits & Relapse' | 'Disclaimer & Approach';
}

export interface RelapseLog {
  id: string;
  date: string;
  trigger: string;
  timeOfDay: string;
  notes: string;
  recoveryAction: string;
}

export interface AssessmentQuestion {
  id: number;
  question: string;
  options: {
    text: string;
    score: number; // 1-4 indicator of need for accountability
    triggerType?: string;
  }[];
}
